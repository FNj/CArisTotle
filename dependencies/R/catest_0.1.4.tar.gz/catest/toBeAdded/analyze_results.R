
#source("./packageSource/validation_classes.R")

plot.mono.res.2 <- function(){
  folder <- list()
  #folder[["mono15T1"]] <- "test/learn_15/test1/"
  #folder[["mono15T2"]] <- "test/learn_15/test1/"
  #folder[["mono20T1"]] <- "test/learn_20/test1/"
  #folder[["exp10ws"]] <- "test/results/wrongSkills/monoExp10/"
  #folder[["exp10wp"]] <- "test/results/wrongMonoPenalty/monoExp10/"
  #folder[["exp15wp"]] <- "test/results/wrongMonoPenalty/monoExp15/"
  #folder[["exp20wp"]] <- "test/results/wrongMonoPenalty/monoExp20/"
  folder[["expert_old_glm"]] <-  "./Bayes/glmexp_re"
  folder[["newExp20"]] <- "test/results/newPenMono20/"
  
  #folder[["exp10"]] <- "test/results/monoExp10/"
  #folder[["exp15"]] <- "test/results/monoExp15/"
  folder[["exp20"]] <- "test/results/monoExp20/"
  
  #folder[["10"]] <- "test/results/monoExp10/"
  #folder[["15"]] <- "test/results/monoExp15/"
  
  #folder[["2s10wp"]] <- "test/results/wrongMonoPenalty/2sMonoExp10/"
  #folder[["2s15wp"]] <- "test/results/wrongMonoPenalty/2sMonoExp15/"
  
  #folder[["mono20T2"]] <- "test/learn_20/test1/"
  #folder[["S5"]] <- "test/s5/"
  #folder[["testo"]] <- "test/testo/"
  folder[["epx"]] <- "test/results/exp/"
  
  #folder[["expert_old_glm"]] <-  "./Bayes/glmexp_re/"
  #folder[["expert_old"]] <-  "./Bayes/tf/expert/newErrorFull/"
  #folder[["expert_glm"]] <-  "./Bayes/glmexp"
  #folder[["expert_new"]] <-  "./Bayes/expert/results"
  #folder[["expert_new_glm"]] <-  "./Bayes/nn_glm_exp_0"
  
  sres <- get.results(folder)
  resm <- get.success.rates(sres)
  
  plot.all.graphs(resm,c(0.60,0.85),c(1,20))
}


plot.mono.res <- function(){
  folder <- list()
  folder[["monoS1"]] <- "test/simulation_monotonic"
  folder[["simple_3s"]] <- "./Bayes/tf3s/simple/nnres/"
  folder[["simple_3s2"]] <- "./Bayes/tf3s/simple/newResults/"
  
  sres <- get.results(folder)
  resm <- get.success.rates(sres)
  
  plot.all.graphs(resm,c(0.60,0.85),c(1,21))
}

plot.neural.res <- function(file = NULL){

  neuralfolder <- list()
  neuralfolder <- dir("./neural/nnresults", full.names = TRUE)
  names(neuralfolder) <- dir("./neural/nnresults")

  folder <- list()
  folder[["neural7x7"]] <- "./neural/nnresults/test_7_7"
  folder[["new7x7"]] <- "./neural/new_pxi_results/test_7x7"
  folder[["new7x7_2"]] <- "./neural/correct_7/"
  folder[["new7x7_3"]] <- "./neural/correct_7_v2/"
  folder[["new7x7_4"]] <- "./neural/correct_7_v3_MINUS/"
  folder[["new7x7_5"]] <- "./neural/correct_7_v3_NOMINUS/"
  sres <- get.results(folder)
  resm <- get.success.rates(sres)

  #load("IRT_res.Rdata")
  #resm[[3]] <- list(res)


  if(!is.null(file)){
    pdf(file, width = 8, height = 5)
    plot.all.graphs(resm,c(0.67,0.85),c(1,21))
    dev.off()
  } else {
    plot.all.graphs(resm,c(0.67,0.85),c(1,21))
  }
  inds <- c(1,2,6,11,16,26)
  for(d in resm){
    print(d[inds])
  }
}

plot.bayes.res <- function(file = NULL){
  folder <- list()
  folder[["simple_3s"]] <- "./Bayes/tf3s/obssimple/newResults/"
  folder[["simple_3s_glm"]] <- "./Bayes/glm/"
  folder[["simple_2x3s"]] <- "./Bayes/tf3s/twoSkills_diff/results/"
  folder[["simple_2x3s_glm"]] <- "./Bayes/glm2p/"
  folder[["glm_3"]] <- "./Bayes/glm_3/"
  folder[["glm_5"]] <- "./Bayes/glm_5/"
  folder[["glm_7"]] <- "./Bayes/glm_7/"
  folder[["glm_9"]] <- "./Bayes/glm_9/"

  sresm <- get.results(folder)
  resm <- get.success.rates(sresm)
  resm[[1]] <- resm[[1]][2:42]

  if(!is.null(file)){
    pdf(file, width = 8, height = 5)
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
    dev.off()
  } else {
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
  }
  inds <- c(1,2,6,11,16,26)
  for(d in resm){
    print(d[inds])
  }
}

plot.bayes.expert <- function(file = NULL){
  folder <- list()
  folder[["expert_old"]] <-  "./Bayes/tf/expert/results"
  folder[["expert_old_glm"]] <-  "./Bayes/glmexp_re"
  #folder[["expert_glm"]] <-  "./Bayes/glmexp"
  folder[["expert_new"]] <-  "./Bayes/expert/results"
  folder[["expert_new_glm"]] <-  "./Bayes/nn_glm_exp_0"

  #folder[["glm_exp"]] <- "./Bayes/glm_exp_3/"
  #folder[["nn_glm_exp_2"]] <-  "./Bayes/nn_glm_exp_2"
  #folder[["nn_glm_exp_1"]] <-  "./Bayes/nn_glm_exp_1"
  #folder[["cglmnee_2"]] <-  "./Bayes/cglmnee_2"
  #folder[["glmnee_0"]] <-  "./Bayes/cglmnee_0"
  #folder[["glmnee_1"]] <-  "./Bayes/cglmnee_1/"
  #folder[["glmnee_2"]] <-  "./Bayes/cglmnee_2"
  #folder[["expert_glm_mean"]] <-  "./Bayes/glmexp_mean"
  sresm <- get.results(folder)
  resm <- get.success.rates(sresm)

  if(!is.null(file)){
    pdf(file, width = 8, height = 5)
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
    dev.off()
  } else {
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
  }
  inds <- c(1,2,6,11,16,26)
  for(d in resm){
    print(d[inds])
  }
}

plot.bayes.comparison <- function(file = NULL){
  load("IRT_res.Rdata")
  resm <- list()
  resm[["IRT"]] <- res

  nfolder <- list()
  nfolder <- dir("./neural/nnresults", full.names = TRUE)
  names(nfolder) <- dir("./neural/nnresults")
  folder <- list()
  folder[["neural_7"]] <- nfolder[["test_7_7"]]
  #folder[["expert_new"]] <-  "./Bayes/expert/results"
  folder[["simple_2x3s_glm"]] <- "./Bayes/glm2p/"
  folder[["expert_new_glm"]] <-  "./Bayes/nn_glm_exp_0"


  sres <- get.results(folder)
  sresm <- get.results(folder)
  resm <- c(resm,get.success.rates(sresm))



  if(!is.null(file)){
    pdf(file, width = 8, height = 5)
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
    dev.off()
  } else {
    plot.all.graphs(resm,c(0.7,0.85),c(1,21))
  }
  inds <- c(1,2,6,11,16,26)
  for(d in resm){
    print(d[inds])
  }
}


all.results.in.folder <- function(path = "./"){
  dirs <- dir(path)
  folders <- paste0(path,dirs)
  names(folders) <- dirs
  res <- get.results(folders)
  res <- get.success.rates(res)
  plot.all.graphs(res,c(0.65,0.95),c(1,39))
}

pull.simple.results <- function(source.folders, as.list = FALSE){
  if(as.list){
    all.results <- list()
  } else {
    all.results <- Result.collection()
  }
  all.files <- c()

  for(source.folder in (source.folders)){
    all.files <- c(all.files, list.files(path=source.folder,pattern = "\\.dat$",full.names =TRUE))
  }
  for(file in all.files){
    load(file)
    if(as.list){
      all.results <- add.to.list(all.results,test.result)
    } else {
      all.results <- add.test.result(all.results,test.result)
    }
  }
  return(all.results)
}


pull.fold.results <- function(source.folder, evidence, fold.size, as.collection=FALSE){
  all.results <- list()
  for(i in 1:fold.size){
    load(paste0(source.folder,"test_",i,"_",evidence,"_result.dat"))
    all.results[[i]] <- test.result
  }
  if(as.collection){
    rc <- Result.collection()
    for(res in all.results){
      rc <- add.test.result(rc,res)
    }
    return(rc)
  } else {
    return(all.results)
  }
}

calculate.succes.rate <- function(results){
  rates <- list()
  num.vars <- length(results[[1]]@steps)
  num.tests <- length(results)
  for(i in 1:num.vars){
    sum <- 0
    unknown.vars <- results[[1]]@steps[[i]]@unknown.variables
    for(result in results){
      sum <- result@steps[[i]]@succ + sum
    }
    rate <- sum / (num.tests*unknown.vars)
    rates <- add.to.list(rates,rate)
  }
  return(rates)
}

#loads folders data and print graph
load.and.create.graphs <- function(folder){
  res <- get.results(folder)
  res <- get.success.rates(res)
  plot.all.graphs(res,c(0.7,1))
}


combine.path.with.folds <- function(data.path){
  dirs <- dir(data.path[[1]], full.names = TRUE)
  return(dirs)
#   path <- paste0(data.path,"fold1")
#     for(i in 2:10){
#       path <- c(path,paste0(data.path,"fold",i))
#     }
#     return(path)
}

#loads results from folders
get.results <- function(data.paths){
  results <- list()
  for(j in 1:length(data.paths)){
    path <- combine.path.with.folds(data.paths[j])
    results[[names(data.paths)[j]]] <- pull.simple.results(path)
  }
  return(results)
}

get.succ.at.steps <- function(succ,steps,roundf,as.char=FALSE){
  succ <- lapply(succ,"[",steps)
  succ <- lapply(succ,round,roundf)
  if(as.char){
  succ <- lapply(succ,function(x) unlist(lapply(x,paste,"&")))
  }
  return(succ)
}

#pulls test data from list of results
get.all.tests.data <- function(results){
  data <- list()
  for(i in 1:length(results@results)){
    data[[i]] <- results@results[[i]]@test.data
  }
  return(data)
}

#pull succes rates from list of results
#if by folder, it reads the results from files first
get.success.rates <- function(results=NULL, by.folder=FALSE, folders=NULL){
  if(by.folder){
    results <- get.results(folders)
  }
  data <- list()
  names <- names(results)
  for(i in 1:length(results)){
    succ <- c()
      for(res in results[[i]]@totals){
        #compatibility with those without initial error
        if(!is.null(res)){
          succ <- c(succ, res@avg.succ.rate)
        } else {
          succ <- c(succ, 0)
        }
      }
      data[[names[i]]] <- succ

  }
  return(data)
}

#get the error(s) of the model in(up to) step k
error.in.step.k <- function(input.network, input.data, evidence.file, evidence.states, points.data, results.folder, init.evidence=FALSE, step=0, fold.id=0, fold.size, all.steps=FALSE){
  bn <- initialize.network(input.network)
  tc <- load.test.data(input.data)
  #results <- list()
  start <- 1
  end <- length(tc@data)
  #browser()

  results <- pull.fold.results(paste0(results.folder,"results/fold",fold.id,"/"),init.evidence,fold.size )

  rates <- list()
  rates[[1]] <- list()
  if(all.steps){
    rep(list(list()),steps )
  }


  for(test.id in start:end){
    tc <- set.test.id(tc,test.id)
    td <- transform.to.nodes(tc,points.data)
    if(init.evidence){
      network <- insert.initial.evidence(bn, evidence.file,evidence.states,test.id)
    } else {
      network <- bn
    }

    for(st in 1:step){

      evidence <- results[[test.id]]@steps[[st]]@evidence
      for(ev in evidence$evidence.row){
        network <- insert.evidence(model = network,ev)
        node <- td@unknown[[ev$name]]
        td@known <- add(td@known,node)
        td@unknown <- remove.node(td@unknown,node)
      }
      #td <- set.question.as.observed(td,evidence$question)
      if(all.steps){
        rates[[step]] <- c(rates[[step]], error.in.this.step(network,td))
      } else {
        if(st == step){
          rates[[1]] <- c(rates[[1]], error.in.this.step(network,td))
        }
      }
    }

  }
  #return(lapply(l,function(x) x/end))
  return(rates)
}


#get the error(s) of the model in(up to) step k
recompile.errors <- function(input.network, input.data, evidence.file, evidence.states, points.data, results.folder, ability.vars, init.evidence=FALSE, fold.id=0){
  #bn <- initialize.network(input.network)
  bn <- input.network
  tc <- load.test.data(input.data)
  if(!isS4(input.network)){
    bn <- initialize.network(input.network)
  } else {
    bn <- input.network
  }

  start <- 1
  end <- length(tc@data)
  results <- pull.simple.results(paste0(results.folder,"results/fold",fold.id,"/"), TRUE)
  steps <- length(results[[1]]@steps)

  for(test.id in start:end){
    cat(paste("\nTest"),test.id,"\n")
    test.result <- results[[test.id]]
    tc <- set.test.id(tc,test.id)
    td <- transform.to.nodes(tc,points.data,bn@nodes)
    if(init.evidence){
      network <- insert.initial.evidence(bn, evidence.file,evidence.states,test.id)
    } else {
      network <- bn
    }
    error.network <- network
    ability.indexes <- node.index(network@nodes, ability.vars)
    step.result <- new("StepResult", abil.succ = 0, step = 0,
                       succ=0, fail=0,
                       unknown.variables = 0,
                       evidence = list())
    e.net <- one.dimensional.marginals(error.network,vars=ability.vars)
    step.result <- compute.error(e.net, test.data, step.result,ability.vars)
    test.result@steps <- add.to.list(test.result@steps,step.result)

    for(st in 1:steps){

      cat(st)
      step.result <- new("StepResult", abil.succ = 0, step = st,
                         succ=0, fail=0,
                         unknown.variables = 0,
                         evidence = test.result@steps[[st]]@evidence)

      evidence <- step.result@evidence
      for(ev in evidence$evidence.row){
        network <- override.evidence(network = network,ev$a ,ev$i)
        #node <- td@unknown[[ev$name]]
        #td@known <- add(td@known,node)
        #td@unknown <- remove.node(td@unknown,node)
      }
      network <- one.dimensional.marginals(network, ability.indexes)
      e.net <- error.network
      for(marg in network@marginals){
        e.net <- override.evidence(e.net,evidence.array = marg@a,variable = marg@i)
      }
      vars <- match(td@all@nodes.names, network@nodes@nodes.names)
      e.net <- one.dimensional.marginals(e.net,vars=vars)
      step.result <- compute.error(e.net, td, step.result,ability.vars)
      test.result@steps <- add.to.list(test.result@steps,step.result)
    }
    save(test.result, file=paste(results.folder,"newResults/fold",fold.id,"/test_",test.id,"_result.dat",sep=""))
  }
  return(TRUE)
}


question.names <- function(indexes= FALSE,network=NULL){
  a.ques <- c("Q1" , "Q2" , "Q3" , "Q4" , "Q5" , "Q6" , "Q7" , "Q8" , "Q9" , "Q10" , "Q11" , "Q12" , "Q13" , "Q14" , "Q15" , "Q19" , "Q20" , "Q21" , "Q22" , "Q23",
              "Q24" , "Q25" , "Q26" , "Q27" , "Q28" , "Q29" , "Q30" , "Q32" , "Q33" , "Q34" , "Q35" , "Q36" , "Q37" , "Q38" , "Q39" , "Q40" , "Q41" , "Q42" , "Q43" , "Q44",
              "Q45" , "Q46" , "Q47" , "Q48" , "Q49" , "Q50" , "Q51" , "Q56" , "Q59" , "Q60" , "Q61" , "Q62" , "Q63")
  if(!indexes){
    return(a.ques)
  } else {
    stopifnot(!is.null(network))
    return(lapply(a.ques,function(x) node.index(network,x)))
  }
}



#get density of variable evidence insertion by steps to final step
get.insertion.times <- function(data,step){
  a.ques <- question.names()
  var.counts <- as.list(rep(0, length(a.ques)))
  names(var.counts) <- a.ques

  all.steps <- rep(list(var.counts),step)
  for(result in data@results){
    for(i in 1:step){
      for(evidence in result@steps[[i]]@evidence$evidence.row){
        all.steps[[i]][[evidence$name]] <- all.steps[[i]][[evidence$name]] + 1
      }
    }
  }
  df <- data.frame(matrix(unlist(all.steps), nrow=length(all.steps), byrow=T))
  names(df) <- a.ques
  #questions which apper in pairs are to be dropped not to cloud the plot
  to.drop <- c("Q9","Q13","Q20","Q22","Q24","Q26","Q28","Q35","Q40","Q42","Q49","Q60")

  return(df[,!(names(df) %in% to.drop)])
}

#plots result in list resulrs as scatter plots for step steps
#orders into nrow*ncol table
all.scatter.plots <- function(results,step,nr,nc){
  #oldpar <- par(mfrow = c(nrow, ncol))
  op <- par(mfrow = c(nr, nc),
            oma = c(5,4,0,0) + 0.1,
            mar = c(0,0,1,1) + 0.1)
  i <- 0
  for(result in results){
    res <- get.insertion.times(result,step)
    #plot.intimes(res,i,step)
    plot.density(res,i,step)
    i <- i + 1
  }
  title(xlab = "Step",
        ylab = "Question ID",
        outer = TRUE, line = 3)
}


#plotdensity
plot.density <- function(df,ind,step){
  first <- TRUE
  vars <- c()
  steps <- c()
  color <- c()
  for(step in 1:nrow(df)){
    row <- df[step,]
    for(i in 1:length(row)){
      if(row[i] != 0){


          vars <- c(vars,i)
          steps <- c(steps,step)
          color <- c(color,(abs(row[[i]]/281-1)))

      }
    }
  }
  steps <- steps - 2
  color <- lapply(color,function(x) x^(3))

  #plot(1, type="n", xlab="", ylab="",xlim = c(0,30),ylim = c(1,44),cex=2)
  plot(steps,vars,col=gray(color),pch=15,cex=2)
  #for(i in 1:length(steps)){
  #  points(steps[i],vars[i],col=gray(color[i]),pch=15)
  #}
}

#plot insertion of variables as scaterr graph
plot.intimes <- function(df,ind,step){
  first <- TRUE
  vars <- c()
  steps <- c()
  sizes <- c()
  for(step in 1:nrow(df)){
    row <- df[step,]
    for(i in 1:length(row)){
      if(row[i] != 0){

      for(v in 1:row[[i]]){
        vars <- c(vars,i)
        steps <- c(steps,step)
        #sizes <- c(sizes,row[i]/10+1)
      }
      }
    }
  }

#  symbols(vars, steps, circles=sizes, ann=F, bg="steelblue2", fg=NULL, xlim = c(0,53), ylim=c(0.5,25))
  smoothScatter(steps,vars,axes=FALSE)
  axis(side = 1,
     at=(1:step)*5,
     #labels = if (ind %/% 3 == 1) (1:step)*5 else FALSE)
     labels = (1:step)*5)
      axis(side = 2, labels = (ind == 0 || ind == 3))
      title(xlab = "Step",
      ylab = "Question ID",
      outer = TRUE, line = 3)
}

#plots all success graphs from data
#data is a list of success vectors
plot.all.graphs <- function(data,lim,xlim=-1){
  if(xlim[1] == -1){
    xlim = c(1,length(data[[1]]))
  }
  pchs <- c(15,16,17,10,15)
  colors <- c("black","red","darkgreen","orange","blue","purple","black")
  plot(xlim[1]:xlim[2]-1,data[[1]][xlim[1]:xlim[2]],type="o",col="black",ylim = lim, xlim=xlim-1, pch=pchs[1], cex=1,lwd=2, xlab = "step",
       ylab = "success rate", xaxt = "n", panel.first=grid())
  axis(side = 1, at = c(seq(from=0, to=40,by=5)), labels = c(seq(from=0, to=40,by=5)))
  abline(v=seq(from=0, to=40,by=5), h=seq(from=0.65, to=0.95,by=0.05), col="gray", lty="dotted", lwd = 1.8)

  if(length(data) > 1){
    for(i in 2:length(data)){
      lines(xlim[1]:xlim[2]-1,data[[i]][xlim[1]:xlim[2]],col=colors[i],cex=1, lwd=2,type = "o",pch=pchs[i])
    }
  }
  legend("bottomright", names(data), col = colors[1:length(data)],cex = 1,
         text.col = "green4", lty = c(1, 1, 1, 1), pch = pchs,
         merge = TRUE, bg = "gray90")

}
