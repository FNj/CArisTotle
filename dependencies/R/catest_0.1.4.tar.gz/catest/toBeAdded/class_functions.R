# return all variables of a list of tables
vars.lst <- function(lst){
  vars <- c() # all variables of lst 
  nr.tabs <- length(lst)
  if (nr.tabs > 0){
    for (idx in 1:nr.tabs)
      vars <- c(vars,table.vars(lst[[idx]]))
    vars <- unique(vars)
  }             
  return(vars)
}

# written by Jiri Vomlel
# function for adding structural elements (lists,vectors) to a list
add.to.list=function(lst,el){
  unlist(list(lst,list(el)),recursive=FALSE)
}

arep <- function(x, MARGIN, dim)
{
  dimx <- dim(x)
  if (is.null(dimx)) dimx <- length(x)
  dimmargin <- dim[MARGIN]
  if (length(dimx) != length(dimmargin) || any(dimx != dimmargin))
    stop("dim(x) does not match dim[MARGIN]")
  perm <- 1:length(dim)
  if (length(MARGIN) != 0) perm <- c(MARGIN, perm[-MARGIN])
  aperm(array(x, dim[perm]), order(perm))
}

# join two lists of tables
join.lists <- function(lst1,lst2){
  if (length(lst2) > 0)
    for (m in 1:length(lst2))
      lst1 <- add.to.list(lst1,lst2[[m]])
  return(lst1)
}



compare.arrays.relative <- function(bi.table,factor = 10){
  return(FALSE)
  t <- mapply(array.division,bi.table@real@a,bi.table@rational@a)
  m <- match(TRUE,t>factor)
  if(!is.na(m)){
    return(TRUE)
  }
  return(FALSE)
}

compare.arrays <- function(bi.table,precision = 10^2){
  t <- abs(q2d(qmq(bi.table@real@a,bi.table@rational@a)))
  m <- match(TRUE,t>precision)
  if(!is.na(m)){
    return(TRUE)
  }
  return(FALSE)
}

compare.arrays.numeric <- function(bi.table){
  t <- max(abs(q2d(qmq(bi.table@real@a,bi.table@rational@a))))
  return(t)
}

array.division <- function(a,b){
  if(is.character(a)) a<-q2d(a)
  if(is.character(b)) b<-q2d(b)
  if(a == 0 & b ==0) return(0)
  if((a==0 & b !=0) | (a!=0 &&b==0)) return(Inf)
  #if(abs(a)>abs(b)) return(abs(a)/abs(b))
  #if(abs(a)<=abs(b)) return(abs(b)/abs(a))
  return(0)
}

combine.indexes <- function(i1,i2){
  i <- union(i1,i2)
  o <- order(i)
  return(i[o])
}

add.to.history <- function(op,tab1,tab2=NULL){
  if(is.null(tab2)){
    operation <- new("UnaryOperation",op=op,tab1=tab1)
  } else {
    operation <- new("BinaryOperation",op=op,tab1=tab1,tab2=tab2)
  }
  return(operation)
}


#divide every element of a rational array by a rational value
divideQ <- function(arr,value){
  val <- qdq(arr,(array(value,dim(arr))))
  return(val)
}

#performs outer operation with rational numbers
q.outer <- function(a1,a2,op="*"){
  if(is.vector(a1)){
    d1<-length(a1)
  }else{
    d1<-dim(a1)
  }
  if(is.vector(a2)){
    d2<-length(a2)
    a<-qxq(a1,array(a2[1],d1))
    for(i in 2:d2){
      a<-c(a,qxq(a1,array(a2[i],d1)))
    }
  }else{
    d2<-dim(a2)
    a<-apply(a2,1:2,function(x) qxq(array(x,d1),a1))
  }
  dim(a)<-c(d1,d2)
  return(a)
}