dir <- list.files("./R",full.names = T)
#dir <- list.files("package/catest/R",full.names = T)
for(file in dir){
  source(file)
}
#load("./data/net.nodes.RData")
