#SETTING UP VARIABLES
#starting test ID
start <- 1
#ending test ID (-1 for all test in data set)
end <- 1
#path to tests to be used for learning (one fold from cross-validation) data
learn.filename <- system.file("extdata", "set1_learn.dat", package="catest")
#path to tests to be used for testing (remaining folds from cross-validation) data
data.filename <- system.file("extdata", "set1_test.dat", package="catest")
#question which should be considered for asking
q <- list(c("Q1"),c("Q12"),c("Q23"),c("Q44"))
selection.criterion <- 1
stopping.criterion <- 1
#'
#loading and preparing test data
tc <- load.simulation.data(data.filename, NULL)
#'
#'
#'
#BAYESIAN NETWORK CAT with generic model
#path to a learned network (.net format)
net.filename <- system.file("extdata", "net_set1.net", package="catest")
#names of skill variables in the network
skill.vars <- c("S1")
#'
#loading the Bayesian network
bayes.net <- initialize.network(net.filename,skill.vars)
#we get an instance of Bayes net model for testing
bayes.net
#'
#starting simulation (in this case we simulate testing of one participant aksing one question)
res <- testing.simulation(bayes.net, tc, q, stopping.criterion = 1, start = start, end = end)
#'
#results are stored in a list where each simulated participant is in one item
#get the first (and only in this case) one
res <- res[[1]]
#'
#response pattern before any questions asked
get.response.pattern(res, 1)
#'
#selected question (field a holds information which state the answer was in)
get.evidence(res, 2)
#response pattern after one question asked
get.response.pattern(res, 2)
#'
#'
#'
#NEURAL NETWORK CAT with generic model
#rbf network
version <- 'rbf'
#hidden layers sizes for forward network
hidden <- c(5)
#hidden layers sizes for backward network
hidden.back <- c(5)
#load NodeList of the neural network to be created
data("net.nodes")
#build the network
neural.net <- create.net(learn.filename, version = version, net.nodes = net.nodes, hidden = hidden, hidden.back = hidden.back, minus = FALSE)
#starting tests (in this case one test and selecting one question)
res <- testing.simulation(neural.net, tc, q, selection.criterion, stopping.criterion, start = start, end = end)
#'
#results are stored in a list where each simulated participant is in one item
#get the first (and only in this case) one
res <- res[[1]]
#'
#response pattern before any questions asked
get.response.pattern(res, 1)
#'
#selected question (field a holds information which state the answer was in)
get.evidence(res, 2)
#response pattern after one question asked
get.response.pattern(res, 2)
