# Performs a validation based on a provided learned network and validation set

#source("./source/parseNetwork.R")
#source("./source/classes_real.R")
#source("./source/validation_classes.R")
#source("./source/neural_classes.R")
library(gRbase)
#library(sna)

# run.testing <- function(input.network, input.data, evidence.file, evidence.states, points.data, out = "out", ability.vars, by.entropy=TRUE, start=1, end=-1,init.evidence=FALSE, QS.test.foler = NULL){
#   nn <- input.network
#
#   tc <- load.simulation.data(input.data)
#   if(end == -1){
#     end <- length(tc@data)
#   }
#
#   for(test.id in start:end){
#     test.result <- NULL
#     if(!is.null(QS.test.foler)){
#       load(paste0(QS.test.foler,"/test_",test.id,"_TRUE_result.dat"))
#     }
#     cat(c("\nNeuralTest ",test.id,"\n"))
#     tc <- set.test.id(tc,test.id)
#     td <- transform.to.nodes(tc,points.data,nn@nodes)
#     cat(tc@data[tc@current.index])
#     test.result <- validate.one.participant(nn, td, ability.vars, old.res = test.result)
#     test.result@test.data <- tc@data[tc@current.index]
#     save(test.result, file=paste("./",out,"/nn_test_",test.id,"_",by.entropy,"_result.dat",sep=""))
#   }
#   return(TRUE)
# }

# run.testing.nn <- function(input.network, test.collection, evidence.file, evidence.states, points.data, out = "out", ability.vars, by.entropy=TRUE, start=1, end=-1,init.evidence=FALSE, QS.test.foler = NULL){
#   nn <- input.network
#   if(end == -1){
#     end <- length(tc@data)
#   }
#
#   results <- list()
#
#   for(test.id in start:end){
#     cat(c("\nNeuralTest ",test.id,"\n"))
#     test.collection <- set.test.id(test.collection,test.id)
#     td <- transform.to.nodes(test.collection,nn@nodes)
#
#     insert.initial.evidence(clean.model, test.collection, test.id)
#     prepare.model(model)
#
#     test.result <- validate.one.participant(nn, td, ability.vars)
#     test.result@test.data <- tc@data[tc@current.index]
#     save(test.result, file=paste("./",out,"/nn_test_",test.id,"_",by.entropy,"_result.dat",sep=""))
#   }
#   return(TRUE)
# }

#' @rdname insert.initial.evidence
setMethod("insert.initial.evidence", signature(model = "NeuralNetwork"),
          function(model, evidence){
            return(model)
          }
)

#' @rdname prepare.model
setMethod("prepare.model", signature(model = "NeuralNetwork"),
          function(model){
            return(model)
          }
)


#' @rdname validate.one.participant
setMethod("validate.one.participant", signature(model = "NeuralNetwork"),
          function(model, test.data, selection.criterion, stopping.criterion){
            network <- model
            test.result <- new("TestResult", steps = list())

            #compute initial error
            step.result <- step.response.pattern(model, 0, list())
            test.result@steps <- add.to.list(test.result@steps,step.result)


            if(!is.null(stopping.criterion)){
              stopp <- stopping.criterion
            } else {
              stopp <- (test.data@number.of.questions)
            }
            #run cycle of question insertion
            for(i in 1:stopp){
              cat(i)
              #pick question and store reference
              pick <- pick.question(network, test.data@unknown, selection.criterion, test.data@questions)
              evidence.row <- pick.evidence.row(pick$states, pick$a ,test.data)
              #insert evidence, set observed
              for(evidence in evidence.row){
                network <- set.state(network, evidence$name, which(evidence$a == 1 )- 1)
              }

              test.data <- set.question.as.observed(test.data,pick$question,test.data@questions)
              #compute error
              step.result <- step.response.pattern(model, 0, pick)
              test.result@steps <- add.to.list(test.result@steps,step.result)
            }
            return(test.result)
          }
)

#' Function to insert an evidence to the NeuralNetwork model
#' @param model NN model
#' @param evidence evidence to be inserted
#' @param keep.separators This option is not in use for NeuralNetworks.
setMethod("insert.evidence", signature(model = "NeuralNetwork"),
          function(model, evidence, keep.separators = FALSE){
            model <- set.state(model, evidence$name, which(evidence$a == 1 )- 1)
            return(model)
          }
)

# pick.question.by.entropy <- function(network,test.data,vars){
#   min <- Inf
#   for(question in 1:length(test.data@questions)){
#     states.and.array <- create.evidence.arrays(network,test.data@questions[[question]],test.data)
#     e <- compute.expected.entropy(network,states.and.array$a,vars)
#     if(e < min){
#       min <- e
#       best <- states.and.array
#       q <- question
#     }
#   }
#   evidence <- pick.evidence.row(best$s, best$a ,test.data)
#   return(list(evidence.row=evidence,question = q))
# }

# pick.evidence.row <- function(states, evidence.array, test.data){
#   nodes <- test.data@unknown[names(states)]
#   obs.states <- c()
#   for(node in nodes@nodes){
#     state <- node@state.observed
#     while(state >= node@number.of.states){
#       state <- state - 1
#     }
#     obs.states <- c(obs.states,state+1)
#
#   }
#   row <- 1
#   while(!all(states[row,] == obs.states)){
#     row <- row+1
#   }
#   return(evidence.array[[row]])
# }


#creates all evidence arrays from list of nodes
# create.evidence.arrays <- function(network,variables.names,test.data){
#   states <- list()
#   nodes <- test.data@unknown[variables.names]
#   for(node in nodes@nodes){
#     states[node@name] <- list(1:node@number.of.states)
#   }
#   states <- expand.grid(states)
#
#   #indexes <- all.indexes(network@nodes,names(states))
#   all <- list()
#   for(combination in 1:length(states[[1]])){
#     comb.ev <- list()
#     for(i in 1:length(states)){
#       evidence.a <- array(0,dim=c(nodes[[i]]@number.of.states))
#       evidence.a[states[[i]][combination]] <- 1
#       comb.ev <- add.to.list(comb.ev,list(a=evidence.a,i=0,name=nodes[[i]]@name))
#     }
#     all <- add.to.list(all, comb.ev)
#   }
#   return(list(a=all,s=states))
# }

setMethod("compute.expected.entropy", signature(model = "NeuralNetwork"),
  function(model,evidence.arr,vars){
  network <- model
  expected.entropy <- 0
  stps <- 1
  nn.res <- c()
  probs <- c()
  for(comb in evidence.arr){
    state.prob <- 1
    nn<-network

    nn@questionChances <- as.vector(make.computation(nn,TRUE))
    nn@questionChances[nn@questionChances < 0] <- 0
    nn@questionChances[nn@questionChances > 1] <- 1
    for(var in comb){
      state <- which(var$a == 1) - 1
      nn <- set.state(nn,var$name,state)
      names(nn@questionChances) <- names(nn@currentState)
      if(state == 1){
        chance <- nn@questionChances[var$name]
      } else {
        chance <- 1 - nn@questionChances[var$name]
      }
      state.prob <- state.prob * chance
    }
    nn.res <- c(nn.res, make.computation(nn, FALSE))
    probs <- c(probs, state.prob)
    stps <- stps * state.prob

  }
  # -mean(diff(nn.res))^2*stps
  expected.entropy <- sum((nn.res - sum(nn.res * probs))^2*probs)
  return(-expected.entropy)
}
)

set.state <- function(nn, var.name, state){
  if(state == 0){
    if(nn@minus){
      nn@currentState[var.name] <- -1
    } else {
      nn@currentState[var.name] <- 0
    }
  } else {
    nn@currentState[var.name] <- 1
  }
  return(nn)
}

make.computation <- function(network, whole, treshold1 = 0, treshold2 = 0.5){
  res <- network@currentState

  for(nn in network@nn1){
    #if(network@version == "neuralnet"){
    #  res <- compute(nn, res)$net.result
    #} else {
      res <- predict(nn, res)
    #}
  }
  #res <- res - treshold1
  #res[res > 1] <- 1
  #res[res < 0] <- 0

  if(whole){

    for(nn in network@nn2){
     # if(network@version == "neuralnet"){
    #    res <- compute(nn, res)$net.result
    #  } else {
        res <- predict(nn, res)
     # }
    }
  }
  #res <- res - treshold2
  #res[res > 1] <- 1
  #res[res < 0] <- 0

  return(res)
}

#' @rdname step.response.pattern
setMethod("step.response.pattern", signature(model = "NeuralNetwork"),
          function(model, step, evidence, test.data){
            results <- make.computation(model, whole = TRUE)
            names(results) <- names(model@currentState)

            step.result <- new("StepResult", step = step, evidence = evidence)
            if(model@minus){
              results <- (results + 1)/2
            }
            results[results > 1] <- 1
            results[results < 0] <- 0

            step.result@resp.pattern <- as.numeric(results)
            return(step.result)
          }
)

#computes error in prediction of vars stored in network@marginals
compute.error <- function(results, test.data, test.result,skill.vars,minus = FALSE){
  if(minus){
    results <- (results + 1)/2
  }
  results[results > 1] <- 1
  results[results < 0] <- 0
  #results <- round(results)
  test.result@resp.pattern <- as.numeric(results)
  for(question in test.data@all@nodes){

      if(!is.na(results[question@name])){
        if(results[question@name] == question@state.observed){
          test.result@succ <- test.result@succ +1
        } else {
          test.result@fail <- test.result@fail +1
        }
      }
#     } else {
#       if(m -1 == node@state.observed){
#         test.result@abil.succ <- test.result@abil.succ +1
#       }
    }

  return(test.result)
}

#Load the learned network and prepare for testing
#Load the learned network and prepare for testing
# initialize.network <- function(input.file){
#   res <- load(input.file)
#   return(res)
# }
