#source("./packageSource/parser_classes.R")



setGeneric("get.next.test", function(tc) standardGeneric("get.next.test"))
# returns the next test data
setMethod("get.next.test",signature(tc="TestCollection"),
          function(tc){
            tc@current.index <- tc@current.index +1
            return(tc)
          }
)
#' Sets the ID in the test collection
#'
#' @param tc test collection to modify
#' @param id test id
#' @exportMethod set.test.id
setGeneric("set.test.id", function(tc,id) standardGeneric("set.test.id"))

#' @rdname set.test.id
setMethod("set.test.id",signature(tc="TestCollection"),
          function(tc,id){
            tc@current.index <- id
            return(tc)
          }
)

setGeneric("add.test.result", function(rc, test.result) standardGeneric("add.test.result"))
# returns the next test data
setMethod("add.test.result",signature(rc="ResultCollection", test.result="TestResult"),
          function(rc, test.result){
            rc <- update.totals(rc,test.result)
            rc@results <- add.to.list(rc@results,test.result)
            return(rc)
          }
)

Result.collection <-function(){
  return(new("ResultCollection",results=list(),totals=list()))
}

# Adds a single observation of testing to validation summary
#
# @param rc Instance of ResultsCollection to be updated.
# @param test.result Result to be inserted
#
# @return Updated ResultsCollection object.
update.totals <- function(rc, test.result){
  if(length(rc@totals) == 0){
    rc@totals <- list()
    for(step in test.result@steps){
      rc@totals[[step@step+1]] <- new("ResultsTotals",step=step@step)
    }
  }
  k <- 0

  for(step in test.result@steps){
    k <- k+1
    rt <- rc@totals[[step@step+1]]
    #if(!old.v && .hasSlot(step, "resp.pattern")){
      a <- test.result@test.data
      if(length(a) > length(step@resp.pattern)){
        warning("Evidence and response pattern lengths do not match!")
        a <- a[1:length(step@resp.pattern)]
      }
      if(length(a) == 1){
        a <- strsplit(a,",")[[1]]
      }
      names <- intersect(names(a), names(step@resp.pattern))
      if(length(names) == 0) names <- names(step@resp.pattern)
      if(length(names) != length(step@resp.pattern)){
        warning("Evidence and response pattern lengths do not match!")
      }
      succ <- sum(round(step@resp.pattern[names]) == a)
      fail <- sum(round(step@resp.pattern[names]) != a)
    #} else {
    #  succ <- step@succ
    #  fail <- step@fail
    #}
    rt@succ = c(rt@succ,succ)
    rt@fail = c(rt@fail, fail)
    rt@succ.rate = c(rt@succ.rate,succ/(fail+succ))
    rt@avg.succ.rate = mean(rt@succ.rate)
    rc@totals[[step@step+1]] <- rt
  }
  return(rc)
}

#' Pulls data of the participant with ID from the test.collection.
#'
#' @param test.collection a dataset of all participants, instance of TestCollection.
#' @param nodes names of nodes which serve as a base to create NodeList.
#' @param questions list with names of nodes which represent question nodes.
#' @return instance of TestData with nodelist of unknown questions.
#' @export
pull.current.data <- function(test.collection, nodes, questions){
  names <- colnames(test.collection@data)

  # get only nodes which are present in the newtwork
  #stopifnot(all(names %in% nodes@nodes.names))
  names <- intersect(names, nodes@nodes.names)

  data <- test.collection@data[test.collection@current.index,]
  l <- NodeList()
  for(i in 1:length(names)){
    node <- new("Node",name=names[i],state.observed= as.numeric(data[i]),number.of.states=nodes[[names[i]]]@number.of.states)
    l <- add(l,node)
  }
  return(new("TestData", unknown = l, all = l, known = NodeList(), number.of.questions = length(questions),
             questions = questions))
}

#' Sets the question as observed in the TestData object. Changes it from unanswered to answered.
#'
#' @param test.data TetsData oject to be used.
#' @param name of the question.
#' @param questions If an individual \code{\link{NodeList-class}} of possible questions is being used. The question to be marked as observed
#'  is pulled out from this list.
#' @return An actualized TestData object.
#' @export
set.question.as.observed <- function(test.data,name,questions = NULL){
  if(is.null(questions)){
    nodes <- test.data@unknown[name]
  } else {
    nodes <- test.data@unknown[test.data@questions[[name]]]
  }
  for(node in nodes@nodes){
    test.data@known <- add(test.data@known,node)
    test.data@unknown <- remove.node(test.data@unknown,node)
  }
  if(!is.null(questions)){
    test.data@questions[[name]] <- NULL
  }

  return(test.data)
}

# written by Jiri Vomlel
# function for adding structural elements (lists,vectors) to a list
add.to.list=function(lst,el){
  unlist(list(lst,list(el)),recursive=FALSE)
}
