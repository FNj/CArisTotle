#' Function loading simulation data from file.
#' @param input.file source file to read simulation data from.
#' @param evidence.file source file to read additional evidence associated with each test.
#' @param sep separator of individual values in the input file.
#' @export
load.simulation.data <- function(input.file, evidence.file, sep = ','){
  data <- read.table(input.file, header = TRUE, sep=sep)

  #load evidence / if any
  if(!is.null(evidence.file)){

    # ev.data <- readLines(evidence.file)
    # for(i in 1:length(ev.data)){
    #   ev.data[[i]] <- str_replace_all(ev.data[[i]],"\"","")
    # }
    # ev.names <- strsplit(ev.data[1],",")[[1]]
    # ev.data <- data.frame(matrix(unlist(strsplit(ev.data[2:length(ev.data)],",")), nrow=length(ev.data[2:length(ev.data)]), byrow=T), stringsAsFactors=FALSE)
    # colnames(ev.data) <- strsplit(ev.names,",")
    #
    ev.data <- read.table(evidence.file,sep=sep,header = T)
  } else {
    ev.data = NULL
  }
  tc <- new("TestCollection", current.index = 0, data = data, evidence.data = ev.data)
  return(tc)
}

# Function used to create a list of all questions as they are in the test.
initialize.questions <- function(){
  q <- list()
  q <- add.to.list(q,c("Q1"))
  q <- add.to.list(q,c("Q2"))
  q <- add.to.list(q,c("Q3"))
  q <- add.to.list(q,c("Q4"))
  q <- add.to.list(q,c("Q5"))
  q <- add.to.list(q,c("Q6"))
  q <- add.to.list(q,c("Q7"))
  q <- add.to.list(q,c("Q8"))
  q <- add.to.list(q,c("Q9"))
  q <- add.to.list(q,c("Q10"))
  q <- add.to.list(q,c("Q11"))
  q <- add.to.list(q,c("Q12"))
  q <- add.to.list(q,c("Q13"))
  q <- add.to.list(q,c("Q14"))
  q <- add.to.list(q,c("Q15"))
  q <- add.to.list(q,c("Q19"))
  q <- add.to.list(q,c("Q21"))
  q <- add.to.list(q,c("Q22"))
  q <- add.to.list(q,c("Q23"))
  q <- add.to.list(q,c("Q24"))
  q <- add.to.list(q,c("Q25"))
  q <- add.to.list(q,c("Q26"))
  q <- add.to.list(q,c("Q27"))
  q <- add.to.list(q,c("Q29"))
  q <- add.to.list(q,c("Q30"))
  q <- add.to.list(q,c("Q32"))
  q <- add.to.list(q,c("Q33"))
  q <- add.to.list(q,c("Q34"))
  q <- add.to.list(q,c("Q35"))
  q <- add.to.list(q,c("Q36"))
  q <- add.to.list(q,c("Q37"))
  q <- add.to.list(q,c("Q38"))
  q <- add.to.list(q,c("Q39"))
  q <- add.to.list(q,c("Q40"))
  q <- add.to.list(q,c("Q41"))
  q <- add.to.list(q,c("Q42"))
  q <- add.to.list(q,c("Q43"))
  q <- add.to.list(q,c("Q44"))
  q <- add.to.list(q,c("Q45"))
  q <- add.to.list(q,c("Q46"))
  q <- add.to.list(q,c("Q47"))
  q <- add.to.list(q,c("Q48"))
  q <- add.to.list(q,c("Q49"))
  q <- add.to.list(q,c("Q50"))
  q <- add.to.list(q,c("Q51"))
  q <- add.to.list(q,c("Q56"))
  q <- add.to.list(q,c("Q59"))
  q <- add.to.list(q,c("Q60"))
  q <- add.to.list(q,c("Q61"))
  q <- add.to.list(q,c("Q62"))
  q <- add.to.list(q,c("Q63"))
  return(q)
}

transform.to.state.number <- function(node.ids,state.values,network){
  v <- list()
  for(i in 1:length(node.ids)){
    v[[i]] <- tr.to.st.num(node.ids[i],state.values[i],network)
  }
  return(unlist(v))
}


tr.to.st.num <- function(node.id,state.value,network){
  if(state.value == ""){
    return(NA)
  }
  if(network@nodes[[node.id]]@name == "age"){
    return((as.numeric(state.value))-16)
  }
  if(is.element(network@nodes[[node.id]]@name,c("math","physics","chemistry"))){
    return(as.numeric(state.value)*2-2)
  }
  names <- network@nodes[[node.id]]@states.names
  for(i in 1:length(names)){
    if(names[i] == state.value){
      return(i-1)
    }
  }
  return(as.numeric(state.value))
}
