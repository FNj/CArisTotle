#' @import gRbase
#' @import methods
#' @import glm2
#' @import stringr
#' @import ltm
#' @import graphics
#' @import stats
#' @import RSNNS
#' @importFrom grDevices dev.off gray pdf
#' @importFrom utils read.table
#' @importFrom boot inv.logit

# @importFrom boot inv.logit

# Performs a validation based on a provided learned network and validation set

#source(paste0("./R/parseNetwork.R"))
#source(paste0("./R/classes_real.R"))
#source(paste0("./R/validation_classes.R"))
library(gRbase)

#' This function can simulate the adaptive testing procedure on the collected dataset.
#'
#' This function can simulate the adaptive testing procedure on the collected dataset. It outputs response patterns of individual participants.
#' The response pattern is a vector of participant's most probable answers given by the model estimation in its current state.
#' This vector is provided for every student, for every step of testing,
#'  i.e., after each question asked. Results are stored in the \code{\link{TestResult}} object.
#'
#' @param model learned input model - the type determines the function used. This package currently supports \code{\link{BayesianNetwork-class}} and
#' \code{\link{NeuralNetwork}} models.
#' @param test.collection contains test data for individual students as well as possible additional evidence. It is stored in an instance of
#'  \code{\link{TestCollection}}
#' Note that if evidence is present, it will be used, otherwise leave NULL in the evidence slot of the \code{\link{TestCollection}}.
#' @param questions is the vector of names of questions which should be asked. Names have to correspond to names of nodes present in the model.
#' @param selection.criterion the criterion to be used to select questions:
#' \enumerate{
#' \item maximizing the entropy reduction on skills variables,
#' \item maximizing variances of skill nodes states,
#' \item maximizing variances of question nodes states.
#' }
#' @param stopping.criterion currently it specifies the number of questions to be asked.
#' The simulation will stop after asking \code{stopping.criterion} questions for each simulated participant.
#' Later, we plan to add more elaborate options to stop the testing procedure.
#' @param output.path output folder for storing results which are named by ID of the currently tested participant.
#' @param start ID of the first parcipant in the dataset for whom the simulation should be done.
#' @param end ID of the last test parcipant in the dataset to be simulated (-1 for all tests from the set).
#'
#' @return A list with individual \code{\link{TestResult}s}, or empty list if output was saved to files.
#' @seealso BayesianNetwork-class
#' @examples
#' #SETTING UP VARIABLES
#'
#' #load the stored BayeBayesianNetwork (see BayesianNetwork-class)
#' #this net was learned using 9/10 of participants
#' example('BayesianNetwork-class',package = 'catest' )
#' #we get an instance of Bayes net model for testing
#' bayes.net
#'
#'
#' #path to file containing participants to be simulated (remaining 1/10 of participants)
#' data.filename <- system.file("extdata", "set1_test.dat", package="catest")
#' #questions which should be considered for asking (sub-selection from nodes contained in the net)
#' questions <- list(c("Q1"),c("Q12"),c("Q23"),c("Q44"))
#'
#' #loading participants data
#' test.collection <- load.simulation.data(data.filename, NULL)
#'
#' #starting simulation (in this case we simulate testing of one participant (start = end = 1) aksing one question (stopping.criterion = 1))
#' res <- testing.simulation(bayes.net, test.collection, questions, stopping.criterion = 1, start = 1, end = 1)
#'
#' #results are stored in a list where each simulated participant is in one item
#' #get the first participant's result
#' res <- res[[1]]
#'
#' #response pattern before any questions asked
#' get.response.pattern(res, 1)
#'
#' #the name of a question which was selected in the fisrt step
#' get.evidence(res, 2)
#' #response pattern after the first question asked
#' get.response.pattern(res, 2)
#'
#'
#'
#' @export
testing.simulation <- function(model, test.collection, questions, selection.criterion = 1, stopping.criterion = 0, output.path = NULL, start=1, end=-1) {

            clean.model <- model
            if(end <= 0){
              end <- nrow(test.collection@data)
            }

            results <- list()

            for(test.id in start:end){
              cat(c("\nTest_N_P ",test.id,"\n"))
              test.collection <- set.test.id(test.collection,test.id)
              td <- pull.current.data(test.collection,clean.model@nodes, questions)

              if(!is.null(test.collection@evidence.data)){
                evidence.data <- test.collection@evidence.data[test.id,]
                model <- insert.initial.evidence(clean.model, evidence.data)
              }
              model <- prepare.model(model)

              test.result <- validate.one.participant(model, td, selection.criterion, stopping.criterion)
              test.result@test.data <- setNames(as.numeric(test.collection@data[test.collection@current.index,]),colnames(test.collection@data))

              #save to file
              if(!is.null(output.path)){
                save(test.result, file=paste("./",output.path,"/test_",test.id,"_",selection.criterion,"_result.dat",sep=""))
              } else {
                results <- add.to.list(results, test.result)
              }
            }
            return(results)
      }

#' Prepares the model for testing. This function performs some incialization steps with the model.
#'
#' @param model model for student modeling
#' @exportMethod prepare.model
setGeneric("prepare.model", function(model) standardGeneric("prepare.model"))

#' @rdname prepare.model
setMethod("prepare.model", signature(model = "BayesianNetwork"),
  function(model){
  model <- one.dimensional.marginals(model, all.indexes(model@nodes))
  return(model)
}
)

#' Runs the validation cycle for one test participant.
#'
#' @param model model for testing
#' @param test.data data of the test to be validated
#' @param selection.criterion criterion to be used to select questions
#' \enumerate{
#' \item entropy
#' \item skill nodes distribution
#' \item questions distibution
#' }
#' @param stopping.criterion currently number of questions to be asked
#' Later we plan to add more elaborate options to stop the testing procedure
#' @return object of TestResult containing selected questions and success reates in every step.
#' @exportMethod validate.one.participant
setGeneric("validate.one.participant", function(model, test.data, selection.criterion, stopping.criterion) standardGeneric("validate.one.participant"))

#' @rdname validate.one.participant
setMethod("validate.one.participant", signature(model = "BayesianNetwork"),
  function(model, test.data, selection.criterion, stopping.criterion){
  network <- model
  test.result <- new("TestResult", steps = list())

  vars <- match(test.data@unknown@nodes.names, model@nodes@nodes.names)
  vars <- vars[!is.na(vars)]
  all.vars <- vars

  #compute initial error
  step.result <- step.response.pattern(model, 0, "", test.data)
  test.result <- add.step.result(test.result,step.result)

  if(!is.null(stopping.criterion) && !(stopping.criterion < 1)){
    stopp <- stopping.criterion
  } else {
    stopp <- (test.data@number.of.questions)
  }
  #run cycle of question insertion
  for(i in 1:stopp){
    cat(i)
    model <- one.dimensional.marginals(model, all.vars)
    #pick question and store reference - requires marginals computed in the network
    #st <- Sys.time()
    pick <- pick.question(model, test.data@unknown, selection.criterion, test.data@questions)
    #cat("\n",Sys.time() - st,"\n")
    #get the correct row based on the selected question
    evidence.row <- pick.evidence.row(pick$states, pick$a ,test.data)
    #insert evidence, set observed
    for(evidence in evidence.row){
      model <- insert.evidence(model=model,evidence=evidence)
    }
    step.result <- step.response.pattern(model, i, test.data@questions[[pick$question]], test.data)
    test.result <- add.step.result(test.result,step.result)

    test.data <- set.question.as.observed(test.data,pick$question,test.data@questions)

  }
  return(test.result)
  }
)

#' This function selects the next suitable question for the student who is currently modeled by the model.
#' The selection is done based on the selection criterion as well.
#' @seealso validate.one.participant
#' @param model model of the tested student
#' @param questions a vector naming possible questions from model nodes. This vector is converted
#'  to NodeList and all names must match nodes inside the model. It is possible to input vector of node indexes 
#'  instead of names. In this case it has to be numeric type vector.
#' @param selection.criterion criterion for selection. See @seealso validate.one.participant
#' @param question.list a list of names of nodes to be asked as questions. This field can
#'  be left NULL in case each Node in \code{questions} param is to be asked individually.
#'   In case you want to asked some of them in gropus, specify it as a single vector in this
#'   \code{question.list}.
#' @param force By default this method checks if questions which have known states
#'  (individual CPT inserted to the network for the particular variable), are not in the question.list,
#'  i.e., if we are not asking a question which was already answered. Trying to use such question would input
#'  impossible evidence and the inference algorith would fail. By default the check stops the execution. If you
#'  are sure you want to do it anyway and override this behaviour use force = TRUE.
#' @return A list containing the selected question from \code{question.list}. This list contains
#'  \code{$question} which is the index of the selected question in the \code{question.list} or the position
#'   of the question node in \code{questions} if \code{question.list} was empty. The field \code{$states} contains
#'    all possible states combinations of the selection (all posible states of one variable if the selection is
#'     singleton). The field \code{$a} then contain prepared arrays for corresponding states (results after asking
#'      the question).
#' @export
pick.question <- function(model, questions, selection.criterion = 1, question.list = NULL, force = FALSE){
  if(!is(questions, "NodeList")){
    questions <- model@nodes[questions]
  }
  if(is.null(questions)) stop("Questions contain nodes which are not in the network")
  
  if(is.null(question.list)){
    question.list <- get.nodes.names(questions)
  } else {
    #if(is.numeric(question.list)) question.list <- model@nodes@nodes.names[question.list]
    if(!all(unlist(question.list) %in% get.nodes.names(questions))) stop("question.list contains values which are not in questions")
  }
  
  model <- one.dimensional.marginals(model, c(unlist(question.list)))#, model@skill.vars))
  
  if(class(model) == "BayesianNetwork" & !force){
    singletons <- find.singleton.tables(model)
    names <- get.nodes.names(model)[singletons]
    if(any(names %in% question.list)){
       stop("A varaible which has a known state (evidence inserted to the network) is in the question.list.
            Inference is likely to fail. Are you sure you are not asking a question which is already answered?")
    }
  }
  if(selection.criterion == 1){
              pick <- pick.question.by.entropy(model, questions, model@skill.indexes, question.list)
            } else if(selection.criterion == 2){
              pick <- pick.question.by.selectionS(model, questions, model@skill.indexes, question.list)
            } else if(selection.criterion == 3){
              pick <- pick.question.by.selectionX(model, questions, model@skill.indexes, question.list)
            } else {
              best <- create.evidence.arrays(model,question.list[[1]], questions)
              #evidence <- pick.evidence.row(best$states, best$a ,test.data)
              pick <- (list(states=best$states,question = 1))
            }
            return(pick)
    }



# pre.compute.error <- function(e.net, network, vars, step, evidence, test.data){
#   step.result <- new("StepResult", step = step, evidence = evidence)
#   network <- one.dimensional.marginals(network,vars= network@skill.indexes)
#   for(marg in network@marginals){
#     e.net <- insert.evidence(e.net,marg)
#     #e.net <- override.evidence(e.net,evidence.array = marg@a,variable = marg@i)
#   }
#   e.net <- one.dimensional.marginals(e.net,vars=vars)
#
#   #compute error
#   step.result <- compute.error(e.net, test.data, step.result,e.net@skill.vars)
#   return(step.result)
# }

#' Computes the response pattern in the validation procedure in the given step
#'
#' @param model current model modeling the tested subject.
#' @param step step ID.
#' @param evidence evidence inserted in this step. list() if empty. This is used only for storing history.
#' @param test.data current test data. It has to contain sets of known and unknown nodes.
#' @return An instance of StepResult containing response pattern.
#' @exportMethod step.response.pattern
setGeneric("step.response.pattern", function(model, step, evidence, test.data) standardGeneric("step.response.pattern"))

#' @rdname step.response.pattern
setMethod("step.response.pattern", signature(model = "BayesianNetwork"),
 function(model, step, evidence, test.data){
  step.result <- new("StepResult", step = step, evidence = evidence)

  model <- mirror.nodes(model, test.data@known@nodes.names)

  nodes.id <- c(model@mirrored.nodes,nodes.indexes(model@nodes, test.data@unknown@nodes.names))
  model <- one.dimensional.marginals(model,vars=nodes.id)

  #compute error
  step.result <- response.pattern(model, step.result)
  return(step.result)
 }
)

# #' Creates copies (clones) of nodes in the Bayesian network. Recreates adjactency matrix and recreates the junction tree.
# #'
# #' @param network to be used.
# #' @param nodeNames names of nodes to be copied.
# #'
# #' @return instance of \code{\link{BayesianNetwork}} containing cloned nodes.
mirror.nodes <- function(network, nodeNames){
  am <- network@orig.adj.matrix
  for(node in nodeNames){
    varid <- ncol(am) + 1
    i <- node.index(network, node)

    #add table to the network
    table <- get.node.table(i,network@tables)

    table@i[which(table@i == i)] <- varid
    table <- reorder.potential(list(a = table@a, i = table@i))
    table <- new("RealConditionalTable",a=table$a,i=table$i)
    network@tables <- add.to.list(network@tables,table)

    network@nodes <- add(network@nodes, Node(paste0(network@nodes[[i]]@name,"_mirror"),
                                             network@nodes[[i]]@states.names,
                                             network@nodes[[i]]@number.of.states))

    network@mirrored.nodes <- c(network@mirrored.nodes, varid)
    #modify adj.matrix

    am <- cbind(am, am[,i])
    colnames(am)[varid] <- varid
    am <- rbind(am, c(am[i,]))
    rownames(am)[varid] <- varid
  }
  am <- moralize(am)
  am <- triangulate(am)
  network@j.tree <-JunctionTree(am, network@tables)
  #network <- BayesianNetwork(am, network@tables,"",NodeList())
  return(network)
}

#' Inserts an initial evidence into the model
#'
#' @param model model to be used
#' @param evidence matrix containing evidence data to be inserted. The matrix has one row, in columns there are names of nodes to be inserted.
#' Names are checked against the model and if they are not present the evidence won't be inserted.
#' @exportMethod insert.initial.evidence
setGeneric("insert.initial.evidence", function(model, evidence) standardGeneric("insert.initial.evidence"))

#' @rdname insert.initial.evidence
setMethod("insert.initial.evidence", signature(model = "BayesianNetwork"),
  function(model, evidence){#test.collection, test.id){
  if(is.null(evidence)){
    return(model)
  }

  names <- colnames(evidence)
  evidence.ind <- nodes.indexes(model@nodes, names)
  #data <- test.collection@evidence.data[test.id,]

  # restrict nodes to only those in the model
  #stopifnot(all(!is.na(evidence.ind)))
  names <- intersect(names, model@nodes@nodes.names)

  #remove those which are not in the model
  names <- names[!is.na(evidence.ind)]
  data <- data[!is.na(evidence.ind)]
  evidence.ind <- evidence.ind[!is.na(evidence.ind)]

  data <- transform.to.state.number(evidence.ind,data,model)
  for(i in 1:length(data)){
    if(!is.na(data[i])){
      a <- array(0,dim= model@nodes[[evidence.ind[i]]]@number.of.states)
      a[data[i]+1] <- 1
      if(model@tables[[evidence.ind[i]]]@a[data[i]+1] == 0){
        cat(paste("INCONSISTENCE EVIDENCE - NOT INSERTED ",names[i]," state ",data[i]+1),"\n")
      } else {
        e.list <- list(a = a, i = evidence.ind[i])
        model <- insert.evidence(model,e.list)
      }
    }
  }
  return(model)
}
)


pick.question.by.entropy <- function(network, questions, skills,question.list){
  min <- Inf

  for(question in 1:length(question.list)){

    states.and.array <- create.evidence.arrays(network,question.list[[question]],questions)
    e <- compute.expected.entropy(network,states.and.array$a,skills)

    if(e < min){
      min <- e
      best <- states.and.array
      q <- question
    }
  }
  #evidence <- pick.evidence.row(best$states, best$a ,test.data)
  return(list(states=best$states, a=best$a, question = q))
}

pick.question.by.selectionS <- function(network,questions,skills,question.list){
  maxi <- -Inf
  best <- NULL
  for(question in 1:length(question.list)){

    states.and.array <- create.evidence.arrays(network,question.list[[question]],questions)
    variance <- compute.expected.varianceS(network,states.and.array$a,skills)

    if(!is.nan(variance)){
      if(variance > maxi){
        maxi <- variance
        best <- states.and.array
        q <- question
      }
    }
  }
  if(is.null(best)) browser()
  #evidence <- pick.evidence.row(best$states, best$a ,test.data)
  return(list(states=best$states, a=best$a, question = q))
}

pick.question.by.selectionX <- function(network,questions,skills,question.list){
  maxi <- -Inf
  for(question in 1:length(question.list)){

    states.and.array <- create.evidence.arrays(network,question.list[[question]],questions)
    variance <- compute.expected.varianceX(network,states.and.array$a,skills)

    if(!is.nan(variance)){
      if(variance > maxi){
        maxi <- variance
        best <- states.and.array
        q <- question
      }
    }
  }
  #evidence <- pick.evidence.row(best$states, best$a ,test.data)
  return(list(states=best$states, a=best$a, question = q))
}


pick.evidence.row <- function(states, evidence.array, test.data){
  nodes <- test.data@unknown[names(states)]
  obs.states <- c()
  for(node in nodes@nodes){
    state <- node@state.observed
    while(state >= node@number.of.states){
      state <- state - 1
    }
    obs.states <- c(obs.states,state+1)

  }
  row <- 1
  while(!all(states[row,] == obs.states)){
    row <- row+1
  }
  return(evidence.array[[row]])
}


#creates all evidence arrays from list of nodes
create.evidence.arrays <- function(network,variables.names,questions){
  states <- list()
  nodes <- questions[variables.names]
  for(node in nodes@nodes){
    states[node@name] <- list(1:node@number.of.states)
  }
  states <- expand.grid(states)

  #indexes <- all.indexes(network@nodes,names(states))
  all <- list()
  for(combination in 1:length(states[[1]])){
    comb.ev <- list()
    for(i in 1:length(states)){
      evidence.a <- array(0,dim=c(nodes[[i]]@number.of.states))
      evidence.a[states[[i]][combination]] <- 1
      comb.ev <- add.to.list(comb.ev,list(a=evidence.a,i=node.index(network,nodes[[i]]@name),name=nodes[[i]]@name))
    }
    all <- add.to.list(all, comb.ev)
  }
  return(list(a=all,states=states))
}

compute.expected.varianceS <- function(network,evidence.arr,vars){
  expected.variance <- 0
  bn<-network
  marginals<-one.dimensional.marginals(bn,c(evidence.arr[[1]][[1]]$i,vars))@marginals
  pp <- marginals[[2]]@a[2]
  px0<- marginals[[1]]@a[1]
  px1<- marginals[[1]]@a[2]
  bn<-network
  bn<-insert.evidence(bn,evidence.arr[[1]][[1]])
  p0<-one.dimensional.marginals(bn,vars)@marginals[[1]]@a[2]
  bn<-network
  bn<-insert.evidence(bn,evidence.arr[[2]][[1]])
  p1<-one.dimensional.marginals(bn,vars)@marginals[[1]]@a[2]
  expected.variance<-(pp-p0)^2*px0+(pp-p1)^2*px1
  return(expected.variance)
}

compute.expected.varianceX <- function(network,evidence.arr,vars){

  expected.variance <- 0
  bn<-network
  marginals<-one.dimensional.marginals(bn,c(evidence.arr[[1]][[1]]$i,vars))@marginals
  rp <- marginals[[1]]@a[2]
  rs0<- marginals[[2]]@a[1]
  rs1<- marginals[[2]]@a[2]
  bn<-network
  e.list <- list(a = evidence.arr[[1]][[1]]$a, i = vars)
  bn<-insert.evidence(bn,e.list)
  r0<-one.dimensional.marginals(bn,evidence.arr[[1]][[1]]$i)@marginals[[1]]@a[2]
  bn<-network
  e.list <- list(a = evidence.arr[[2]][[1]]$a, i = vars)
  bn<-insert.evidence(bn,e.list)
  r1<-one.dimensional.marginals(bn,evidence.arr[[1]][[1]]$i)@marginals[[1]]@a[2]
  expected.variance<-(rp-r0)^2*rs0+(rp-r1)^2*rs1
  return(expected.variance)
}


setGeneric("compute.expected.entropy", function(model,evidence.arr,vars) standardGeneric("compute.expected.entropy"))
setMethod("compute.expected.entropy", signature(model = "BayesianNetwork"),
 function(model,evidence.arr,vars){
   network <- model
  expected.entropy <- 0
  stps <- 0

  for(comb in evidence.arr){
    state.prob <- 1
    bn<-network
    for(var in comb){
      bn <- insert.evidence(bn,var,TRUE)
      state.prob <- state.prob*get.marginals.by.id(network@marginals,var$i)[which(var$a == 1)]
    }
    clqs <- get.cliques.of.variable(bn@j.tree, bn@tables[[length(bn@tables)]]@i[[1]])
    if(length(clqs) == 1 && length(vars) == 1){
      marginals <- list(normalize(marginal.from.clique.marginal(vars[[1]], clique.marginal(clqs[[1]], bn))))
    } else {
      marginals <- one.dimensional.marginals(bn,vars)@marginals
    }
    entropy <- 0
    for(marginal in marginals){
      logs <- apply(marginal@a,1,log2)*marginal@a
      logs[is.nan(logs)] <- 0
      entropy <- entropy - sum(logs)
    }

    expected.entropy <- expected.entropy + entropy*state.prob
    stps <- stps + state.prob
  }
  return(expected.entropy)
 }
)

get.marginals.by.id <- function(marginals,id){
  for(marg in marginals){
    if(length(marg@i) == 1){
      if(marg@i[1] == id){
        return(marg@a)
      }
    }
  }
}


compute.error.old <- function(network, test.data, test.result,skill.vars){
  for(marg in network@marginals){
    bn.index <- marg@i[1]
    name <- network@nodes@nodes[[bn.index]]@name
    m <- which(marg@a == max(marg@a))
    node <- get.node(test.data@all,name)

    #if it is not the ability variable
    if(!is.element(name,skill.vars)){
      test.result@unknown.variables <- test.result@unknown.variables +1

      if((m -1) == node@state.observed){
        test.result@succ <- test.result@succ +1
      } else {
        test.result@fail <- test.result@fail +1
      }
    } else {
      if((m -1) == node@state.observed){
        test.result@abil.succ <- test.result@abil.succ +1
      }
    }
  }
  return(test.result)
}

#' Creates a response pattern based on the given model (BN) state.
#' @param model BN network
#' @param step.result object of StepResult to store data to
#'
#' @return An updated StepResult
response.pattern <- function(model, step.result){
  for(marg in model@marginals){
    bn.index <- marg@i[1]
    m <- which(marg@a == max(marg@a))
    name <- str_replace(model@nodes@nodes[[bn.index]]@name,"_mirror","")
    step.result@resp.pattern[name] <- m-1
  }
  return(step.result)
}

#' Load the learned Bayesian Network and prepare it for testing.
#'
#' This function loads a Bayesian network form .net file. This network can afterwards be used for testing simulation by
#'  \code{\link{testing.simulation}} or to test participants truly online individually.
#' @param input input network. It is either a paht to .net file stored on disk or the string containing .net representation.
#' @param skill.vars names of nodes which serve as skill variables
#' @param type sets either Bayesian Network ('bayesian') or Neural network ('neural')
#' @param is.file if true input param gives the path to the .net file, otherwise it shoul contain the .net as string
# #' @param biconditional.tables if set to TRUE CPTs are biconditional (both REAL and COMPLEX numbers), otherwise they are only REAL - 
# #' this functionality is no longer maintainde, proceed on your own risk.
#' @export
initialize.network <- function(input, skill.vars, type="bayesian", is.file = TRUE){ #, biconditional.tables=FALSE){
#initialize.network <- function(input.file, skill.vars, biconditional.tables = FALSE, type="bayesian"){
  biconditional.tables <- FALSE
  if(type == "bayesian"){
    res <- load.network(input, is.file)
    bn <- BayesianNetwork(res$adj.matrix,res$potentials,skill.vars, res$nodes, FALSE)

    return(bn)
  } else {
    res <- load(input.file)
    return(res)
  }
}

#Plot the graph of the network
plot.graph <- function(adj.matrix, nodes){
  rownames(adj.matrix) <- nodes@nodes.names
  colnames(adj.matrix) <- nodes@nodes.names
  b <- as(adj.matrix,"graphNEL")
  plot(b)
}
