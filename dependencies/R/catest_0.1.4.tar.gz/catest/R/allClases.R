setClassUnion("numericORcharacterORnull", c("character", "numeric", "NULL"))
setClassUnion("numericORnull", c("numeric", "NULL"))
setClassUnion("dfORnull", c("data.frame", "NULL"))

#' Class to contain \code{\link{Node}s}.
#' @slot number.of.nodes length of this list.
#' @slot nodes.names vector of nodes names.
#' @slot nodes list containing nodes.
setClass("NodeList", representation(number.of.nodes = "numeric",
                                    nodes.names = "numericORcharacterORnull",
                                    nodes = "list"))

#' Class to represent a single node of a model.
#' @slot name is its name.
#' @slot states.names is a vector with names of states (if needed).
#' @slot states.values is a vector (numeric) with values of states (if needed, i.e., different from states position).
#' @slot state.obsereved if the node was already obsereved this slot holds the observed value.
#' @slot number.of.states is the number of possible state values of this node.
#' @aliases Node
setClass("Node", representation(name = "character",
                                states.names = "character",
                                states.values = "numeric",
                                state.observed = "numericORnull",
                                number.of.states = "numeric"))



#' Class holding the whole data set to be tested.
#'
#' @slot current.index of the currently tested participant.
#' @slot data \code{data.frame} containing all participants to be tested. Columns are questions and individual rows are participants.
#' @slot evidence.data NULL or \code{data.frame} with evidence for each participant (corresponding with participants answers stored in \code{data}).
#' @aliases TestCollection
setClass("TestCollection", representation(current.index = "numeric",
                                          data = "data.frame",
                                          evidence.data = "dfORnull"))

#' A class representing a single test
#'
#' @slot number.of.questions the number of questions
#' @slot unknow list of unknown questions
#' @slot know list of already known (answered) questions
#' @slot all all questions present in this test
#' @slot questions list of all questions
setClass("TestData", representation(number.of.questions = "numeric",
                                    unknown = "NodeList",
                                    known = "NodeList",
                                    all = "NodeList",
                                    questions = "list"))

#' A class holding the result of a participant in a single step.
#' @slot resp.pattern of the participant in this step. This vector contains the most probable state of variables estimated by the model in this step.
#' @slot evidence which was inserted just before this step. It containes the name of the last question which was asked before the model got into this state.
#' @slot step holds the index of this step.
#' @aliases StepResult
#' @seealso \link{TestResult-class}
setClass("StepResult", representation(resp.pattern = "numeric",
                                      evidence = "character",
                                      step = "numeric"))

#' Class holding the result of a single test.
#'
#' This class serves as a container for answers of a single participant.
#' @slot steps in this slot inidividual \code{\link{StepResult}} instances are stored. The index of a step corresponds to
#'  time when the question was asked. The state before testing has index 1, after asking the first question the index is 2, etc.
#' @slot test.data this vector holds real answers of the participant, i.e., what the participant answered, not what the model estimated.
#'  Fill in 0s for questions which were not answered.
#' @aliases TestResult
setClass("TestResult", representation(steps = "list", test.data = "numeric"))

#' A class for simpler storage of collection of statistical data from individual TestResults
setClass("ResultsTotals", representation(succ = "numeric",
                                         fail = "numeric",
                                         succ.rate = "numeric",
                                         avg.succ.rate = "numeric",
                                         step = "numeric"))


#' A class holding a collection of all TestResults and maintaining their totals
setClass("ResultCollection", representation(results = "list", totals = "list"))

#' Function to retrieve a response pattern from a TestResult
#' @param test.result TestResult instance to retrieve from
#' @param step index of the step
#' @exportMethod get.response.pattern
setGeneric("get.response.pattern", function(test.result, step) standardGeneric("get.response.pattern"))
#' @rdname get.response.pattern
setMethod("get.response.pattern", signature(test.result = "TestResult"),
          function(test.result, step){
            return(test.result@steps[[step]]@resp.pattern)
          }
)

#' Function to access an Evidence from a TestResult
#' @param test.result TestResult to pull from
#' @param step index of the step
#' @rdname get.evidence
#' @exportMethod get.evidence
setGeneric("get.evidence", function(test.result, step) standardGeneric("get.evidence"))

#' @rdname get.evidence
setMethod("get.evidence", signature(test.result = "TestResult"),
          function(test.result, step){
            return(test.result@steps[[step]]@evidence)
          }
)

#' Function to add \code{\link{StepResult}} to the \code{\link{TestResult}} collection
#' @param test.result TestResult instance to insert StepResult into
#' @param step.result StepResult to be inserted
#' @param step index of the step
#' @exportMethod add.step.result
setGeneric("add.step.result", function(test.result, step.result, step = -1) standardGeneric("add.step.result"))
#' @rdname add.step.result
setMethod("add.step.result", signature(test.result = "TestResult"),
          function(test.result, step.result, step = -1){
            #test.result@steps <- add.to.list(test.result@steps,step.result)
            if(step == -1){
              step <- length(test.result@steps)+1
            }
            test.result@steps[[step]] <- step.result
            return(test.result)
          }
)

#' Function to access a StepResult from a TestResult
#' @param test.result TestResult to pull from
#' @param step index of the step
#' @rdname get.step.result
#' @exportMethod get.step.result
setGeneric("get.step.result", function(test.result, step) standardGeneric("get.step.result"))
#' @rdname get.step.result
setMethod("get.step.result", signature(test.result = "TestResult"),
          function(test.result, step){
            return(test.result@steps[[step]])
          }
)

setClassUnion("numericORcharacter", c("character", "numeric"))

#' Class for conditional table.
#' @slot a is a conditional probability table P(X|pa(X))
#' @slot i are variables it describe in the increasing order in the order of dimensions.
#' @seealso \code{\link{BayesianNetwork}}
#' @aliases ConditionalTable
setClass("ConditionalTable", representation(a = "array", i = "numericORcharacter", name="character", parent="character"))
#setClass("RationalConditionalTable", representation(), contains="ConditionalTable")
setClass("RealConditionalTable", representation(), contains="ConditionalTable")
#setClass("BiConditionalTable", representation(real="RealConditionalTable",rational="RationalConditionalTable", history="Operation"),
#         contains="ConditionalTable")


setClass("Operation", representation(op="character", tab1="ConditionalTable"))
setClass("UnaryOperation", representation(), contains="Operation")
setClass("BinaryOperation", representation(tab2="ConditionalTable"), contains="Operation")

#' Class representing a junction tree of a \code{\link{BayesianNetwork}}.
#' @aliases JunctionTree
setClass("JunctionTree", representation(cliques = "list", separators="list", parents="integer", adjacent = "list",
                                        nr.cliques="integer", clique.tables="list", sep.potentials="list"))
#' Class representing an instance of Bayesian network.
#'
#' @slot tables \code{\link{ConditionalTable}} storing conditional probabilities.
#' @slot vars names of variables in the network.
#' @slot adj.matrix adjactency matrix of the network.
#' @slot j.tree \code{\link{JunctionTree}} of the network. This slot stores one specific junction tree constructed for inference.
#' @slot marginals a list containing computed marginals. This slot is used to store result after calling \code{\link{one.dimensional.marginals}}
#'  to store resulting marginals. Each item of a list contains the marginal for one node.
#' @slot skill.vars names of variables which are as skill nodes in the network.
#' @slot skill.indexes indexes of the corresponding skill varialbes in the network.
#' @examples
#' # file to load network from
#' # this specific BayesianNetwork has been learned in order to use crossvalidation from 9/10 of model participants.
#' net.filename <- system.file("extdata", "net_set1.net", package="catest")
#' # names of skill variables in the network
#' skill.vars <- c("S1")
#'
#' # load the network from file
#' bayes.net <- initialize.network(net.filename,skill.vars)
#' bayes.net
#' @seealso \code{\link{BayesianNetwork}}
setClass("BayesianNetwork", representation(tables = "list", vars = "numericORcharacter", adj.matrix = "matrix",
                                           orig.adj.matrix = "matrix", mirrored.nodes = "numeric",
                                           j.tree = "JunctionTree", marginals = "list", nodes = "NodeList",
                                           skill.vars = "character", skill.indexes = "numeric"))

