#' catest: A package for computerized adaptive testing.
#'
#'  This package provides a framework for computerized adaptive testing.
#'  It allows using different models to perform testing of participants using Bayesian networks or Neural networks.
#'  The package allows to run simulated computerized adaptive test procedure for samples collected in datasets.
#'  Please see \code{\link{testing.simulation}} method for an example usage of this functionality.
#'  It is also possible to perform real adaptive testing since all the necessary methods are exported and available to drive an actual testing procedure.
#'
#' @references
#' M. Plajner, J. Vomlel: Bayesian network models for adaptive testing, In: Proceedings of the Twelfth UAI Bayesian Modeling Applications Workshop (BMAW 2015). Aachen: CEUR Workshop Proceedings, 2015, ISSN 1613-0073. Available from: http://ceur-ws.org/Vol-1565/
#'
#' M. Plajner, J. Vomlel: Probabilistic Models for Computerized Adaptive Testing: Experiments, Technical report, ArXiv: 1601.07929
#'
#' M. Plajner, J. Vomlel: Student Skill Models in Adaptive Testing, In: Proceedings of the Eighth International Conference on Probabilistic Graphical Models, JMLR Workshop and Conference Proceedings, 2016, Available from: http://jmlr.org/proceedings/papers/v52/
#' @docType package
#' @name catest
#' @examples
#' #This example presents the way how to use this package to online testing of individual participants.
#' #load the stored BayesianNetwork (see BayesianNetwork-class)
#' #this net was learned using 9/10 of participants
#' example('BayesianNetwork-class',package = 'catest' )
#'
#' #insert the evidence about the participant (if known and present in the net - age, gender, ...)
#' #in this example we do not add any evidence
#' #evidence.data <- matrix(c(2,3), nrow = 1)
#' #colnames(evidence.data) <- c("var1", "var2")
#' #bayes.net <- insert.initial.evidence(bayes.net, evidence.data)
#'
#' #if we already know some ansewers we have to insert them into the network
#' answered.questions <- c("Q56", "Q1")
#' answered.states <- c(1, 2)
#' bayes.net <- insert.evidence(model=bayes.net, evidence=answered.questions, state = answered.states)
#'
#' #to compute marginals, the following line may now be used
#' #vars <- node.index(bayes.net,get.nodes.names(bayes.net)) #get indexes of nodes in the network
#' #bayes.net <- one.dimensional.marginals(bayes.net, node.index(model,vars))
#'
#' #***incialization completed***
#'
#' #obtain a question to be asked
#' #questions input must be in the form of an instance of a NodeList
#' names <- c("Q2", "Q3", "Q4","Q5") #names of questions to be asked
#' questions <- NodeList()
#' for(i in 1:length(names)){
#'  node <- new("Node",name=names[i],number.of.states=2)
#'  questions <- add(questions,node)
#' }
#'
#' #question.list contain a list of question combintions possible for asking. It is possible to include joined questions.
#' #jde o to, ze zde muzou byt napr. dvojice Nodu, ktere jsou v seznamu questions, protoze se maji polozit dohromady
#' #pokud takova situace neni (a v nasem pripade nejspis nebude) je mozne tento parametr vynechat a pak se berou vsechny otazky
#' #z questions zvlast. questions by tedy musely obsahovat pouze dosud nepolozene otazky. Na druhou stranu lze i questions nechat
#' #nemenne a menit jen question.list (neco jako question.list = questions - answered.questions)
#'
#' question.list <- list("Q2", c("Q3", "Q4"), "Q5")
#' pick <- pick.question(bayes.net, questions, selection.criterion = 1, question.list = question.list)
#'
#' #navratova hodnota je trosku komplexnejsi opet kvuli moznosti polozeni svazanych otazek. viz napoveda return:
#' # A list containing the selected question from \code{question.list}. This list contains
#' #  \code{$question} which is the index of the selected question in the \code{question.list} or the position
#' #   of the question node in \code{questions} if \code{question.list} was empty. The field \code{$states} contains
#' #    all possible states combinations of the selection (all posible states of one variable if the selection is
#' #     singleton). The field \code{$a} then contain prepared arrays for corresponding states (results after asking
#' #      the question).
#'
#' # pole $a a $states je pro vas zrejme celkem nezajmave (jsou to predpriravena pole k vlozeni evidence - stejna jako ta pri
#' # vkladani z answered.questions). Pozor na situace, kde odpoved zahrnuje vice uzlu (svazane otazky). Tudiz je mozne, ze jedine
#' # zajimave je $question, coz je index moznosti z question.list
#'
#' # položit otázku a získat odpověď a zkontrolovat
#'
#' # pokud je dosaženo ukončovacího kritéria, ukončit test (buďto čas nebo počet otázek)
#'
#' # získat výsledky
#'
NULL

