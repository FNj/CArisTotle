#adjacent[[i] contains the list of indexes of cliques adjacent to jt$cliques[[i]] - possibly empty NULL
adjacent.cliques <- function(j.tree){
  nr.cliques <- length(j.tree$cliques)
  adjacent <- vector("list",  nr.cliques)
  for (i in 1:nr.cliques){
    j <- j.tree$parents[[i]]
    if (j > 0){
      adjacent[[i]] <- union(adjacent[[i]],j)
      adjacent[[j]] <- union(adjacent[[j]],i)
    }
  }
  return(adjacent)
}

# tables[[i]] contains the list of indexes of tables attached to jt$cliques[[i]] - possibly empty NULL
tables.for.cliques <- function(j.tree, tables){
  nr.cliques <- length(j.tree$cliques)
  clique.tables <- vector("list",  nr.cliques)
  for (i in 1:length(tables)){
    idx <- (1:nr.cliques)[as.logical(is.insetlist(table.vars(tables[[i]]), j.tree$cliques, index=TRUE))][1]
    clique.tables[[idx]] <- c(clique.tables[[idx]],i)
  }
  return(clique.tables)
}

# the implementation of the lazy propagation:
# - the input is a list of all tables and the output are tables attached to all separators
all.clique.marginals <- function(network, PRINT = FALSE){
  nr.cliques <- network@j.tree@nr.cliques
  stopifnot(nr.cliques > 0)
  visited <- rep(FALSE,nr.cliques)
  inf.holder<-list(sep.messages=list(),visited=visited)
  while (!all(inf.holder$visited)){ # for all connectivity components of the junction tree (resp. the junction forest) do
    root.clq <- (1:nr.cliques)[!inf.holder$visited][1]
    inf.holder <- collect.evidence(i=0, j=root.clq, network, inf.holder, PRINT=PRINT)
    inf.holder$sep.messages <- distribute.evidence(i=0, j=root.clq, network,inf.holder$sep.messages, PRINT=PRINT)
  }
  return(inf.holder$sep.messages)
}

# collect evidence is invoked from clique i on clique j
collect.evidence <- function(i,j,network,inf.holder,PRINT=FALSE){
  if (PRINT) cat("collect.evidence(",i,",",j,")\n")
  #inf.list <- list(lst.sep=lst.sep,visited=visited)
  inf.holder$visited[j] <- TRUE
  nr.adj <- length(network@j.tree@adjacent[[j]])
  if (nr.adj > 0)
    for (ind in 1: nr.adj){
      k <- network@j.tree@adjacent[[j]][ind]
      if (k != i){
        inf.holder <- collect.evidence(i=j, j=k, network, inf.holder,PRINT=PRINT)
      }
    }
  if (i > 0) inf.holder$sep.messages <- absorb.evidence(i=i, j=j, network, inf.holder$sep.messages,PRINT=PRINT)
  return(inf.holder)
}

#' Function to insert an evidence to the \code{\link{BayesianNetwork-class}} model
#' @param model BN model
#' @param evidence evidence to be inserted
#' @param keep.separators Allows to retain separators to remain the same.
#' Use this option only if you are sure that separators remain unchanged.
#' @exportMethod insert.evidence
setGeneric("insert.evidence", function(model, evidence, state = NULL, keep.separators = FALSE) standardGeneric("insert.evidence"))
#' @rdname insert.evidence
setMethod("insert.evidence", signature(model = "BayesianNetwork", evidence = "list"),
  function(model, evidence, state = NULL, keep.separators = FALSE){
    if(!is.null(evidence$a)){
      evidence <- list(evidence)
    }
    for(ev in evidence){
      evidence.array <- ev$a
      variable <- ev$i
      table <- new("RealConditionalTable",a=evidence.array,i=variable)
      names(table@i) <- model@nodes@nodes.names[variable]
      model@tables <- add.to.list(model@tables,table)
      #model@nodes <- add(model@nodes, Node(paste0(model@nodes[[variable]]@name,"_evidence"),
      #                                         model@nodes[[variable]]@states.names,
      #                                         model@nodes[[variable]]@number.of.states))
    }
    if(keep.separators) sep <- model@j.tree@sep.potentials
    model@j.tree <-JunctionTree(model@adj.matrix, model@tables)
    if(keep.separators) sep -> model@j.tree@sep.potentials
    return(model)
    }
)

#' @rdname insert.evidence
setMethod("insert.evidence", signature(model = "BayesianNetwork", evidence = "character"),
    function(model, evidence, state){
      if(is.null(state))stop("If using names to insert evidence, state cannot be empty")
      
      ev <- list()  
      for(i in 1:length(evidence)){
        a <- array(rep(0, model@nodes[[evidence[i]]]@number.of.states), dim = model@nodes[[evidence[i]]]@number.of.states)
        a[state[i]] <- 1
        index <- node.index(model, evidence[i])
        ev <- add.to.list(ev, list(a = a, i = index))
      }
      return(insert.evidence(model, ev))
    }
)

#insert evidence to the network - Martin Plajner
override.evidence <- function(network, evidence.array, variable){
  network@tables[[variable]]@a <- evidence.array
  return(network)
}

diff.with.names <- function(v1,v2){
  ii <- c()
  for(i in 1:length(v1)){
    if(!(v1[i] %in% v2)){
      ii <- c(ii, i)
    }
  }
  return(v1[ii])
}

# absorb evidence for clique i at clique j
absorb.evidence <- function(i,j,network,lst.sep,PRINT=FALSE){

  # cat("absorb.evidence(",i,",",j,")\n")
  if (j > 0){
    lst.j <- clique.tables(j,network) # tables of clique j
    lst.ij <- tables.separators(j,i,lst.sep) # tables for separators jk such that k!=i (j is the receiver and i is the transmitter)
    lst.ij <- join.lists(lst.j,lst.ij) # tables for clique j and separators joined together
    vars.i <- c()
    vars <- vars.lst(lst.ij) # all variables of lst.ij

    # if (i > 0) vars.i <- cliques[[i]] # variables of clique i
    # vars <- diff.with.names(vars, vars.i) # all variables of clique i that are not in the separator of i and j
    if (j > 0) vars.j <- network@j.tree@cliques[[j]] # variables of clique j
    if (i > 0) vars.i <- network@j.tree@cliques[[i]] # variables of clique i
    vars.separator <- intersect(vars.j,vars.i)
    vars <- diff.with.names(vars, vars.separator) # all variables of clique j that are not in the separator of i and j
    nr.vars <- length(vars)
    if (nr.vars > 0)
      for (idx in 1:nr.vars){# the order might be important for the efficiency and the precision !!!!!
        v <- vars[idx]
        lst.ij <- margin.out.from.list(lst.ij, v) # marginalize out a variable v from a list lst
      }
    lst.sep <- add.to.list(lst.sep,list(receiver=i,transmitter=j,lst=lst.ij))
    if (PRINT) cat(" separator [[", length(lst.sep), "]] was added \n")
  }
  return(lst.sep)
}

# marginalize out a variable v from a list lst
margin.out.from.list <- function(lst, v, PRINT=FALSE){
  if (PRINT) cat(" eliminating ", v, "\n", sep="")
  if (PRINT){
    cat(" from lst = \n")
    print(lst)
  }
  tab1 <- combine.all.arrays(lst,v,PRINT=PRINT)
  if (PRINT){
    cat(" combined array\n")
    print(tab1)
  }
  if (length(tab1@i) > 0){ # marginalize out v
    set2 <- diff.with.names(tab1@i,v)
    if (PRINT) cat(" marginalize to", set2, "\n")
    tab2 <- margin.array(tab1, set2)
    if (PRINT){
      cat(" marginalized array\n")
      print(tab2)
    }
  }else{
    tab2 <- tab1
  }
  lst <- remove.all.arrays(lst,v)
  if (length(tab2@i) > 0){
    lst <- add.to.list(lst,tab2)
  }
  return(lst)
}

# marginalize down to the set j
# elements of j are assumed to be ordered
margin.array <- function(t1,j){
  i <- t1@i
  d <- table.dim(t1)
  if (length(j)==0){
    a <- table.from.table.sum(t1,j)
  }else{
    stopifnot(length(diff.with.names(j,i))==0)
    j.corr = c()
    for (i1 in 1:length(j))
      for (i2 in 1:length(i))
        if (j[i1] == i[i2])
          j.corr = c(j.corr,i2)
    table <- table.apply.sum(t1,j.corr,j,dim=d[j.corr])
  }
  return(table)
}

# return all tables of separators for the receiver where the trasmitter is not i
tables.separators <- function(receiver,i,lst.sep,PRINT=FALSE){
  lst <- list() # tables for separators
  nr.sep <- length(lst.sep)
  if (nr.sep > 0)
    for (idx in 1:nr.sep)
      if ((lst.sep[[idx]]$receiver == receiver) && (lst.sep[[idx]]$transmitter != i)){
        lst <- join.lists(lst,lst.sep[[idx]]$lst)
        if (PRINT) {
          cat("lst.sep[[",idx,"]]\n")
          cat("receiver =", lst.sep[[idx]]$receiver, " transmitter =", lst.sep[[idx]]$transmitter, "\n")
        }
      }
  return(lst)
}

# distribute evidence is invoked from clique i on clique j
distribute.evidence <- function(i,j,network,lst.sep,PRINT=FALSE){
  if (PRINT) cat("distribute.evidence(",i,",",j,")\n")
  if (i > 0) lst.sep <- absorb.evidence(i=j, j=i, network,lst.sep,PRINT=PRINT)
  nr.adj <- length(network@j.tree@adjacent[[j]])
  if (nr.adj > 0)
    for (ind in 1:nr.adj){
      k <- network@j.tree@adjacent[[j]][ind]
      if (k != i) lst.sep <- distribute.evidence(i=j, j=k, network,lst.sep,PRINT=PRINT)
    }
  return(lst.sep)
}

setGeneric("clique.tables", function(j, network) standardGeneric("clique.tables"))
# return all tables of a clique j in a network
setMethod("clique.tables",signature(network="BayesianNetwork"),
          function(j,network){
            lst.j <- list() # tables of clique j
            if ((j > 0) && (j < network@j.tree@nr.cliques + 1)){
              cl.tab <- network@j.tree@clique.tables[[j]]
              nr.tabs <- length(cl.tab)
              if (nr.tabs > 0)
                for (idx in 1:nr.tabs)
                  lst.j <- add.to.list(lst.j,network@tables[[cl.tab[idx]]])
            }
            return(lst.j)
          }
)



combine.dimensions <- function(i,i1,i2,d1,d2){
  d <- as.vector(matrix(0,nrow=length(i)))
  j1 <- 1
  j2 <- 1
  for (j in 1:length(i)){
    if (j1 <= length(i1))
      if (i[j] == i1[j1]) {
        d[j] <- d1[j1]
        j1 <- j1+1
      }
    if (j2 <= length(i2))
      if (i[j] == i2[j2]) {
        d[j] <- d2[j2]
        j2 <- j2+1
      }
  }
  return(d)
}

# multiply (if op = "*") or divide (if op = "/") two arrays a1 <- t1$a and a2 <- t2$a
# idexed by sets of integers i1 <- t1$i and i2 <- t2$i, respectively.
# i1 and i2 can be in any set relation.
# However, elements of i1 and i2 are assumed to be ordered and correspond to the array
# indexes (i.e. arrays are assumed to be permuted accordingly)
combine.arrays <- function(t1, t2, op="*", PRINT=FALSE){
  i1 <- table.vars(t1)
  i2 <- table.vars(t2)
  i <- combine.indexes(i1,i2)
  if (PRINT){
    cat("t1 = \n")
    print(t1)
    cat("t2 = \n")
    print(t2)
  }
  if ((length(i1) == 0) || (length(i2) == 0)){
    if (op == "*") table <- t1*t2
    if (op == "/") table <- t1/t2
  }else{
    if (length(intersect(i1,i2))==0){
      table <- table.outer(t1,t2,op)
    }else{
      diff1 <- (length(diff.with.names(i,i1))!=0)
      diff2 <- (length(diff.with.names(i,i2))!=0)
      i.new <- 1:length(i)
      i1.new = i.new[is.element(i,i1)]
      i2.new = i.new[is.element(i,i2)]
      if (PRINT){
        print(t1)
        print(t2)
        cat(" diff1 = ", diff1, " diff2 = ", diff2, "\n")
        cat(" i.new = ", i.new, " i1.new = ", i1.new, " i2.new = ", i2.new, "\n")
        cat(" dim(a1) = ", table.dim(t1), " dim(a2) = ", table.dim(t2), "\n")
      }
      if (diff1 || diff2){
        d <- combine.dimensions(i.new,i1.new,i2.new,table.dim(t1),table.dim(t2))
        if (PRINT) cat(" d = ", d, "\n")
      }
      if (diff1) t1 <- table.arep(t1, i1.new, d)
      if (diff2) t2 <- table.arep(t2, i2.new, d)
      if (op == "*") table <- t1*t2
      if (op == "/") table <- t1/t2
    }
  }
  #******************************** MOVE  TO  STAT  FUNCTION ********************************#
  #a.min <- min(qabs(qmin(a)))
  #a.max <- max(qabs(qmax(a)))
  #VAL.MIN = min(VAL.MIN, a.min)
  #VAL.MAX = max(VAL.MAX, a.max)
  #max.table.size <<- max(max.table.size,length(a)) # global variable


  #return(list(a=a,i=i,VAL.MIN = VAL.MIN,  VAL.MAX = VAL.MAX))
  return(table)
}

# remove all arrays of i
remove.arrays <- function(lst,i){
  stopifnot(length(lst) > 0)
  res <- list()
  for (j in 1:length(lst)){
    if(is(lst,"ConditionalTable")){
      l<-!is.element(i,lst[[j]]@i)
    } else {
      l<-!is.element(i,lst[[j]]$i)
    }
    if(l)
      res <- add.to.list(res,lst[[j]])
  }
  return(res)
}

# combine all arrays containing index i
combine.all.arrays <- function(lst,i,op="*",PRINT=FALSE){
  stopifnot(length(lst) > 0)
  # initialize res
  res <- list()
  #****************************  MOVE TO STAT FUNCTION ************************************************
  #VAL.MIN <- Inf
  #VAL.MAX <- 0
  for (j in 1:length(lst))
    if (is.element(i,lst[[j]]@i))
      if (length(res)==0){
        #****************************  MOVE TO STAT FUNCTION ************************************************
        #VAL.MIN <- min(VAL.MIN,min(qabs(lst[[j]]$a)))
        #VAL.MAX <- max(VAL.MAX,max(qabs(lst[[j]]$a)))
        res <- lst[[j]]
      }else{
        if (PRINT) {
          cat("res = \n")
          print(res)
          cat("lst[[",j,"]] = \n", sep="")
          print(lst[[j]])
        }
        res <- combine.arrays(res,lst[[j]],op,PRINT=PRINT)
        #****************************  MOVE TO STAT FUNCTION ************************************************
        #VAL.MIN <- min(VAL.MIN,res$VAL.MIN)
        #VAL.MAX <- max(VAL.MAX,res$VAL.MAX)
      }
  return(res)
}

# remove all arrays containing index i
remove.all.arrays <- function(lst,i){
  stopifnot(length(lst) > 0)
  res <- list()
  for (j in 1:length(lst))
    if (!is.element(i,lst[[j]]@i))
      res <- add.to.list(res,lst[[j]])
  return(res)
}

#' Function to compute one dimensional marginals in the \code{\link{BayesianNetwork-class}} for variables in vars
#' @param network BN network
#' @param vars list of variables
#' @exportMethod one.dimensional.marginals
setGeneric("one.dimensional.marginals", function(network,vars) standardGeneric("one.dimensional.marginals"))
#' @rdname one.dimensional.marginals
setMethod("one.dimensional.marginals", signature(network = "BayesianNetwork", vars = "numeric"),
          function(network,vars){
            if(is.null(names(vars))){
              names(vars) <- network@nodes@nodes.names[vars]
            }
              stopifnot(length(vars)>0)
              # perform the inference, i.e. compute the lists of tables for separators
              network <- add.separator.potentials(network)
              nr.cliques <- network@j.tree@nr.cliques
              stopifnot(nr.cliques > 0)
              lst.marg <- list()
              for (ind in 1:length(vars)){
                var <- vars[ind]
                clq <- 0
                for (ind2 in 1:nr.cliques)
                  if (is.element(var,network@j.tree@cliques[[ind2]])) clq <- ind2
                stopifnot(clq > 0)
                lst <- clique.marginal(j=clq, network,PRINT=FALSE) # all tables
                temp<-marginal.from.clique.marginal(var=var, lst=lst, PRINT=FALSE)
                tab <- normalize(temp )
                lst.marg <- add.to.list(lst.marg,tab)
              }
              network@marginals <- lst.marg
              return(network)
          }
)
setMethod("one.dimensional.marginals", signature(network = "BayesianNetwork", vars = "character"),
          function(network,vars){
            vvars <- node.index(network, vars)
            names(vvars) <- vars
            return(one.dimensional.marginals(network, vvars))
          }
)



add.separator.potentials <- function(network){
  network@j.tree@sep.potentials <- all.clique.marginals(network)
  return(network)
}

# if evidence was collected and distributed then we get the list of tables representing the marginal over the variables of clique j
clique.marginal <- function(j,network,PRINT=FALSE){
  if (PRINT) cat("clique.marginal(",j,")\n")
  lst <- list()
  if (j > 0){
    lst.j <- clique.tables(j,network) # tables of clique j
    lst.ij <- tables.separators(receiver=j,i=0,lst.sep=network@j.tree@sep.potentials) # tables for all separators
    if(length(lst.ij) > 0){
      for(i in 1:length(lst.ij)){
        names(lst.ij[[i]]@i) <- network@nodes@nodes.names[lst.ij[[i]]@i]
      }
    }
    lst <- join.lists(lst.j,lst.ij) # tables for clique j and separators joined together
  }
  return(lst)
}

# compute one-dimensional marginal from the list of tables (of a clique)
# assumes that var is a variable of some table in the list
marginal.from.clique.marginal <- function(var,lst,PRINT=FALSE){
  vars <- vars.lst(lst) # all variables of lst
  stopifnot(is.element(var,vars))
  vars <- diff.with.names(vars, var) # all variables that are to be marginalized out
  nr.vars <- length(vars)
  if (nr.vars > 0){
    for (idx in 1:nr.vars){
      v <- vars[idx]
      lst <- margin.out.from.list(lst, v, PRINT=PRINT) # marginalize out a variable v from a list lst
    }
  }
  tab <- list(a=array(1,dim=c(1)),i=var)
  if (length(lst) > 0){
    tab <- lst[[1]]
    if (length(lst) > 1)
      for (ind in 2:length(lst))
        tab <- combine.arrays(tab,lst[[ind]])
  }
  return(tab)
}

get.cliques.of.variable <- function(j.tree, var){
  clq <- c()
  if(var %in% j.tree@cliques[[1]]){
    clq <- c(clq, 1)
  }
  for(i in 2:(j.tree@nr.cliques - 1)){
    if(var %in% j.tree@cliques[[i]] || var %in% j.tree@separators[[i]] || var %in% j.tree@separators[[i-1]]){
      clq <- c(clq, i)
    }
  }
  if(var %in% j.tree@cliques[[j.tree@nr.cliques]]){
    clq <- c(clq, j.tree@nr.cliques)
  }
  return(clq)
}

#' Function to retrive node's table
#' @param nodeID node ID
#' @param tables list of tables
#' @export
get.node.table <- function(nodeID, tables){
  for(table in tables){
    if(nodeID %in% table@i && length(table@i) != 1){
      return(table)
    }
  }
  return(NULL)
}
