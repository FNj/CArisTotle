library(ltm)

plot.all.curves <- function(coefs){
  f <- irt.f(coefs[1,1],coefs[1,2])[[1]]
  plot(f,xlim = c(-10,10), xlab = expression(theta), ylab = "P")

  for(i in 2:nrow(coefs)){
    f <- irt.f(coefs[i,1],coefs[i,2])[[1]]
    curve(f,add = TRUE)
  }
}

plot.all.curves.grm <- function(coefs){
  f <- irt.f(coefs[[1]][1],coefs[[1]][2])[[1]]
  plot(f,xlim = c(-10,10), xlab = expression(theta), ylab = "P")

  for(i in 2:length(coefs)){
    f <- irt.f(coefs[[i]][1],coefs[[i]][2])[[1]]
    curve(f,add = TRUE)
  }
}

irt.f <- function(bik = 2, bi = 1, cor = TRUE){
  if(cor){
    e <- bquote(1 - 1/(1+exp(.(bi)*(z-.(bik)))))
  } else {
    e <- bquote(1/(1+exp(.(bi)*(z-.(bik)))))
  }

  func <- function(x){env <- new.env(); assign("z", x, envir=env);
  return(eval(e,env))}
  func.d <- function(x){env <- new.env(); assign("z", x, envir=env);
  return(eval(D(e,'z'),env))}
  info.gain <- function(x){env <- new.env(); assign("z", x, envir=env);
  return(eval(D(e,'z'),env)^2/(eval(e,env)*(1-eval(e,env))))}
  return(list(func,func.d,info.gain))
}

all.probs <- function(coefs, theta){
  igs <- c()
  for(i in 1:nrow(coefs)){
    fs <- irt.f(coefs[i,1],coefs[i,2])
    igs <- c(igs,fs[[1]](theta))
  }
  return(igs)
}

all.ig <- function(coefs, theta){
  igs <- c()
  for(i in 1:nrow(coefs)){
    fs <- irt.f(coefs[i,1],coefs[i,2])
    igs <- c(igs,fs[[3]](theta))
  }
  return(igs)
}

fit.from.data <- function(path){
  data <- read.table(path, header = TRUE, sep = ",")
  #data <- data[,13:length(data)-1]
  return(grm(data))
}

estimate.questions <- function(fit, evidence, unanswered, true.values){
  zval <- factor.scores(fit, resp.patterns = evidence)$score.dat['z1']
  probs <- all.probs(coef(fit), zval)
#   for(qid in unanswered){
#     est.res <- estimate.one.question(fit, evidence, qid, c(1,2))
#     resp.pattern <- c(resp.pattern, which.max(est.res) -1)
#   }
  resp.pattern <- round(unlist(probs))
  score <- sum(resp.pattern == true.values)
  return(score/length(unanswered))
}

# load.res <- function(dir){
#   results <- c()
#   for(fold in 1:10){
#     load(paste0(dir,"first_20/fold",fold,"_res.dat"))
#     results <- c(results, infold.results)
#   }
#   results <- data.frame(matrix(unlist(results), nrow=280, byrow=T))
#   return(colMeans(results))
# }


run.fold <- function(fold){
  path <- paste0("./data/set",fold,"_learn.dat")
  test.path <- paste0("./data/set",fold,"_test.dat")

  fit <- fit.from.data(path)
  test.data <- read.table(test.path, header = TRUE, sep = ",")
  infold.results <- list()
  for(i in 1:28){
    cat(paste("RUNNING TEST", i, "\n"))
    test.res <-  run.test(fit, test.data[i,])
    infold.results[[i]] <- test.res
  }
  save(infold.results, file = paste0("fold",fold,"_res.dat"))
  return(infold.results)
}

run.test <- function(fit, true.values, type = "GRM"){
  #evidence <- matrix(NA, 1, 53)
  unanswered <- 1:53
  res <- factor.scores(fit)
  evidence <- res[[1]][1,1:53]
  evidence[1:53] <- NA
  rate <- estimate.questions(fit = fit, evidence = evidence,
                             unanswered = unanswered, true.values = true.values)
  q.sequence <- c()
  for(step in 1:35){
    #browser()
    next.q <- get.next.question(fit, evidence, unanswered)
    #unanswered <- unanswered[unanswered != next.q]

    if(type == "GRM"){
      evidence[1,next.q] <- true.values[1,next.q] + 1
    } else {
      evidence[1,next.q] <- true.values[1,next.q]
    }
    rate <- c(rate, estimate.questions(fit, evidence, unanswered, true.values))
    q.sequence <- c(q.sequence,next.q)
  }
  return(rate)
}

get.next.question <- function(fit, evidence, unanswered){
  zval <- factor.scores(fit, resp.patterns = evidence)$score.dat['z1']
  res <- c()
  answered <- which(!is.na(evidence))
  igs <- all.ig(coef(fit),zval)
  igs <- unlist(igs)
  igs[answered] <- 0
  return(which.max(igs))
}

# get.results <- function(){
#   step.sums <- rep(0,35)
#   for(i in 1:2){
#     load(paste0("./fold",i,"_res.dat"))
#     step.sums <- get.step.sums(infold.results, step.sums)
#   }
#   return(step.sums/56)
# }

get.step.sums <- function(rates, step.rates){
  s <- 0
  for(j in 1:35){
    for(i in 1:28){
      s <- s + rates[[i]][j]
    }
    step.rates[j] <- step.rates[j] + s
    s <- 0
  }
  return(step.rates)
}
