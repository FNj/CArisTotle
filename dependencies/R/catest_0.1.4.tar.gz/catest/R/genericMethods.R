#setGeneric("run.testing", function(e1) standardGeneric("table.array"))
#setMethod("table.array", "RationalConditionalTable",function(e1){if(is.character(e1@a)){return(q2d(e1@a))}else{return(e1@a)}})
#setMethod("table.array", "RealConditionalTable",function(e1){return(e1@a)})
