
Node <- function(name, states, number.of.states){
  return(new("Node",name=name,states.names=states
             ,number.of.states=number.of.states))
}

#' Adds a node to a list
#' @param e1 \code{\link{NodeList-class}}
#' @param e2 \code{\link{Node}}
#' @export
setGeneric("add", function(e1,e2) standardGeneric("add"))
#' @rdname add
setMethod("add", signature(e1="NodeList", e2="Node"),
          function(e1,e2) {
            e1@number.of.nodes <- e1@number.of.nodes + 1
            e1@nodes[[e1@number.of.nodes]] <- e2
            e1@nodes.names <- c(e1@nodes.names,e2@name)
            return(e1)
          }
)

#remove a node from a list
setGeneric("remove.node", function(e1,e2) standardGeneric("remove.node"))
setMethod("remove.node", signature(e1="NodeList", e2="Node"),
          function(e1,e2) {
            e1@number.of.nodes <- e1@number.of.nodes - 1
            e1@nodes[node.index(e1,e2@name)] <- NULL
            e1@nodes.names <- e1@nodes.names[e1@nodes.names != e2@name]
            return(e1)
          }
)

#' Function to provide names of nodes in a model or NodeList.
#' @param e1 instance of \code{\link{NodeList}} or \code{\link{BayesianNetwork-class}}
#' @exportMethod get.nodes.names
setGeneric("get.nodes.names", function(e1) standardGeneric("get.nodes.names"))
#' @rdname get.nodes.names
setMethod("get.nodes.names", signature(e1 = "NodeList"), function(e1){
  return(e1@nodes.names)
}
)
#' @rdname get.nodes.names
setMethod("get.nodes.names", signature(e1 = "BayesianNetwork"), function(e1){
  return(e1@nodes@nodes.names)
}
)

# get a node name
setGeneric("get.node.name", function(model, index) standardGeneric("get.node.name"))
setMethod("get.node.name", signature(model = "BayesianNetwork",index="numeric"), function(model, index){
  return(model@nodes[[index]]@name)
}
)


# get a node
setGeneric("get.node", function(e1, name) standardGeneric("get.node"))
setMethod("get.node", signature(e1 = "NodeList",name="character"), function(e1, name){
  return(e1@nodes[node.index(e1,name)][[1]])
}
)

# get a node
setMethod("get.node", signature(e1 = "NodeList", name="numeric"), function(e1, name){
  return(e1@nodes[[name]])
}
)


# obtain all states of nodes
setGeneric("node.states", function(e1) standardGeneric("node.states"))
setMethod("node.states", signature(e1 = "NodeList"), function(e1){
  states <- c()
  for(node in e1@nodes){
    states <- c(states, node@number.of.states)
  }
  return(states)
}
)

# obtain names of all nodes
setGeneric("update.node.names", function(e1) standardGeneric("update.node.names"))
setMethod("update.node.names", signature(e1="NodeList"), function(e1){
  e1@nodes.names <- c("")
  for(node in e1@nodes){
    e1@nodes.names <- c(e1@nodes.names,node@name)
  }
  return(e1)
}
)

# get node ID
setGeneric("nodes.indexes", function(e1, name) standardGeneric("nodes.indexes"))
setMethod("nodes.indexes", signature(e1="NodeList"), function(e1, name){
  return(as.numeric(sapply(list=e1,name,node.index)))
}
)

# get all nodes IDs
setGeneric("all.indexes", function(e1) standardGeneric("all.indexes"))
setMethod("all.indexes", signature(e1="NodeList"), function(e1){
  ind <- c()
  for(node in e1@nodes){
    ind <- c(ind,node.index(e1,node@name))
  }
  return(ind)
}
)

# get node ID
setGeneric("index", function(e1, e2) standardGeneric("index"))
setMethod("index", signature(e1="NodeList", e2="Node"), function(e1, e2){
  return(node.index(e1,e2@name))
}
)

#' Returns the index of a Node in a NodeList by its name
#' @param list NodeList to be searched
#' @param name name of the searched Node
#' @exportMethod node.index
setGeneric("node.index", function(list, name) standardGeneric("node.index"))
#' @rdname node.index
setMethod("node.index", signature(list="NodeList"), function(list, name){
  names <- c()
  for(n in name){
    names <- c(names,which(list@nodes.names == n))
  }
  return(names)
}
)

#' @rdname node.index
setMethod("node.index", signature(list="BayesianNetwork"),
          function(list, name) {
            return(node.index(list@nodes,name))
          }
)

#' @rdname node.index
setMethod("node.index", signature(list="NeuralNetwork"),
          function(list, name) {
            return(node.index(list@nodes,name))
          }
)

#' Access to items of NodeList
#' @param x x
#' @param i i
#' @param j j
#' @param ... ...
#' @param drop very standart drop
setMethod("[", c("NodeList", "vector", "missing", "ANY"),
          function(x, i, j, ..., drop=TRUE)
          {
            if(is.numeric(i)){
              initialize(x, nodes=x@nodes[i], number.of.nodes = length(i), nodes.names = x@nodes.names[i])
            }
          })

#' Access to items of NodeList
#' @param x x
#' @param i i
#' @param j j
#' @param ... ...
#' @param drop very standart drop
setMethod("[", c("NodeList", "character", "missing", "ANY"),
          function(x, i, j, ..., drop=TRUE)
          {
            i <- sapply(list=x,i,node.index)
            callGeneric(x,i)
          })

#' Access to items of NodeList
#' @param x x
#' @param i i
#' @param j j
#' @param ... ...
#' @param drop very standart drop
setMethod("[", c("NodeList", "integer", "missing", "ANY"),
          function(x, i, j, ..., drop=TRUE)
          {
            initialize(x, nodes=x@nodes[i], number.of.nodes = length(i), nodes.names = x@nodes.names[i])
          })

#' Access to items of NodeList
#' @param x x
#' @param i i
#' @param j j
#' @param ... ...
#' @param drop very standart drop
setMethod("[[", c("NodeList", "numeric", "ANY"),
          function(x, i, j, ..., drop=TRUE)
          {
            return(x@nodes[[i]])
          })

#' Access to items of NodeList
#' @param x x
#' @param i i
#' @param j j
#' @param ... ...
#' @param drop very standart drop
setMethod("[[", c("NodeList", "character", "ANY"),
          function(x, i, j, ..., drop=TRUE)
          {
            return(x@nodes[[node.index(x,i)]])
          })

setGeneric("reorder.nodes", function(x, order) standardGeneric("reorder.nodes"))
setMethod("reorder.nodes", c("NodeList", "character"),
          function(x, order)
          {
            l <- list()
            for(name in order){
              i <- node.index(x,name)
              l <- add.to.list(l,x@nodes[[i]])
            }
            initialize(x, nodes=l, number.of.nodes = x@number.of.nodes, nodes.names = order)
          })
