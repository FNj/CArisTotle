#source("./RCfunctions.R")
library(glm2)

get.table.probs <- function(coefs,states = 3){
  M <- list()
  for(i in 1:nrow(coefs)){
    M[[i]] <- create.probs.array.small(coefs[i,], states)
  }
  return(M)
}

create.probs.array <- function(coefs, states, thetas){
  shift <- floor(states/2)
  combinations <- expand.grid(rep(list(-shift:shift),thetas))
  combinations <- cbind(1, combinations)
  probs.array <- matrix(0,nrow = nrow(coefs), ncol = nrow(combinations))
  for(i in 1:nrow(coefs)){
    probs.array[i,] <- mapply(inv.logit, as.matrix(combinations) %*% coefs[i,])
  }
  return(list(combinations = combinations,probs.array = probs.array))
}

plot.probs.graphs <- function(coefs){
  ticks <- seq(-5,5,0.1)
  n <- length(ticks)
  M <- matrix(rep(ticks,ncol(coefs)),ncol = ncol(coefs))
  M[,1] <- 1
  for(i in 1:nrow(coefs)){
    vals <- M   %*% coefs[i,]
    plot(ticks, inv.logit(vals), type="l")
    if(vals[50] > vals[51]) cat(i)
  }
}

create.probs.array.small <- function(coefs, states = 3){
  shift <- floor(states/2)
  if(coefs[1] == 0) coefs[1] <- 0.0000001
  thetas <- sum(coefs != 0) - 1
  probs.array <- array(1,dim = c(rep(states,thetas),2))
  combinations <- expand.grid(rep(list(-shift:shift),thetas))
  combinations <- cbind(1, combinations)
  probs <- inv.logit(as.matrix(combinations) %*% coefs[coefs != 0])
  probs[probs[,1] > 0.999999,1] <- 0.9999999
  probs[probs[,1] < 0.000001,1] <- 0.0000001
  probs <- c(as.vector(1-probs),as.vector(probs))
  return(probs.array * probs)
}


get.new.coefs <- function(new.priors, adj.matrix){

  thetas <- ncol(adj.matrix)
  variables <- nrow(adj.matrix)
  new.coefs <- matrix(0,nrow = variables, ncol = thetas + 1)
  ll <- 0
  for(i in 1:(variables)){

    y <- new.priors[,i]
    w <- new.priors[,"weight"]

    x <- list()
    formula <- "y ~ "

    for(t in 1:thetas){
      if(adj.matrix[i,t] == 1){
        tname <- paste0("theta",t)
        x[[t]] <- new.priors[,tname]
        aa <- abs(sum(new.priors[,tname][which(new.priors[,i] == 0)]))
        ac <- length(which(new.priors[,i] == 0))
        if(round(aa) == ac){
          cat("DATA CORRECTION\n")
          y <- c(y,0)
          x[[t]] <- c(x[[t]],1)
          w <- c(w,1)
        }
        aa <- abs(sum(new.priors[,tname][which(new.priors[,i] == 1)]))
        ac <- length(which(new.priors[,i] == 1))
        if(round(aa) == ac){
          cat("DATA CORRECTION\n")
          y <- c(y,1)
          x[[t]] <- c(x[[t]],0)
          w <- c(w,1)
        }
        if(t > 1){
          formula <- paste0(formula, " + ")
        }
        formula <- paste0(formula, "x[[",t,"]]")
      }
    }

    for(t in 1:length(x)){
      while(length(x[[t]]) != max(mapply(length,x))){
        x[[t]] <- c(x[[t]],0)
      }
    }
#     form <- paste0(names(new.priors)[i]," ~ theta1")
#     if(thetas > 1){
#       for(j in 2:thetas){
#         form <- paste0(form," + theta",j," ")
#       }
#     }
#    model <- glm2(form,weights = weight, family = binomial(), data = new.priors)
    model <- glm2(as.formula(formula),weights = w, family = binomial(), data = new.priors)

    coefs <- model$coefficients
    if(!model$converged){
      cat("DID NOT CONVERGED")
      coefs <- c(0,rep(1,sum(adj.matrix[i,])))
    }

    ll <- ll + logLik(model)
    new.coefs[i,c(1,which(adj.matrix[i,] == 1)+1)] <- coefs
  }
  return(list(new.coefs,ll))
}

llikelihood <- function(coefs, vals, ptheta){
  #ps <- array(0, dim = c(nrow(vals), length(ptheta)))
  rr <- create.probs.array(coefs, states = ncol(ptheta), thetas = nrow(ptheta))
  combinations <- rr[[1]]
  probs.array  <- rr[[2]]

  ps <- c()
  for(i in 1:nrow(vals)){
    probs <- ll.individual.conditional.probability(ptheta,vals[i,],probs.array,combinations)
      ps[i] <- sum(probs["probs"])
  }

  #ps <- apply(ps, 1, sum)
  ps <- log(ps)
  return(ps)
}

# logit.conditional.prob <- function(coefs, theta, x){
#   p <- irt.inv.logit(coefs, theta)
#   if(x == 0){
#     p <- 1-p
#   }
#   return(p)
# }

answer.prob <- function(logit.val, x){
  if(x == 0){
    return(1-logit.val)
  }
  return(logit.val)
}

ll.individual.conditional.probability <- function(ptheta, x, probs.array, combinations){
  probs <- rep(1, nrow(combinations))
  for(i in 1:length(x)){
    probs <- probs * answer.prob(probs.array[i,],x[i])
  }
  combinations[,"probs"] <- probs
  return(combinations)
}

individual.conditional.probability <- function(ptheta, x, probs.array, combinations,thetas.counts,CPTs, ptop){

  top <- TRUE
  if(is.null(CPTs)){
    top <- FALSE
    CPTs <- list()
    for(i in 1:nrow(ptheta)){
      CPTs[[i]] <- t(t(ptheta[1,]))
    }
  }
  topstates <- ncol(CPTs[[1]])

  probs <- rep(1, nrow(combinations))
  for(i in 1:length(x)){
    probs <- probs * answer.prob(probs.array[i,],x[i])
  }
  pprobs <- normalize.vector(probs)

  res <- data.frame()
  for(j in 1:topstates){
   pt <- combinations
   pt[,1] <- NULL
   pt <- pt+((ncol(ptheta) -1)/2 + 1)
   pt <- cbind(pprobs, pt)
   for(i in 1:nrow(ptheta)){
     #pt[,i+1] <- ptheta[i,pt[,i+1]]^thetas.counts[i]
     #pt[,i+1] <- ptheta[i,pt[,i+1]]
     pt[,i+1] <- CPTs[[i]][,j][pt[,i+1]]*ptop[j]
   }
   probs <- apply(pt,1,prod)
   if(top){
    top1 <- rep(j,nrow(combinations))
    res <- rbind(res,cbind(combinations,top1,probs))
   } else {
     res <- rbind(res,cbind(combinations,probs))
   }
  }
  return(res)
}

all.conditional.probs <- function(coefs, ptheta, dx, simple.vals, thetas.counts, CPTs, ptop, ntop = 1){
  #create data frame with particular rows
  topstates <- 0
  #if(ntop > 0){
  #  topstates <- 2
  #}
  d <- data.frame(matrix(ncol = ncol(dx)+1+nrow(ptheta)+ntop+topstates,nrow = 0))
  #d <- data.frame(matrix(ncol = ncol(dx)+1+nrow(ptheta)+ntop,nrow = 0))
  t <- c()
  for(i in 1:nrow(ptheta)){
    t <- c(t,paste0("theta",i))
  }
  to <- c()
  ts <- c()
  if(ntop > 0){
    for(i in 1:ntop){
      to <- c(to,paste0("top",i))
      #for(j in 1:topstates){
      #  ts <- c(ts,paste0("probs",j))
      #}
    }
  }
  colnames(d) <- c(colnames(dx),t,to,"weight",ts)

  #prior probabilities of theta
  shift <- floor(ncol(ptheta)/2)
  combinations <- expand.grid(rep(list(-shift:shift),nrow(ptheta)))
  combinations <- cbind(1, combinations)
  probs.array <- matrix(0,nrow = ncol(dx), ncol = nrow(combinations))
  for(i in 1:nrow(coefs)){
    probs.array[i,] <- mapply(inv.logit, as.matrix(combinations) %*% coefs[i,])
  }

  #get individual probabilities for each theta configuration

  values <- c(-1,0,1)

  for(i in 1:nrow(dx)){
    ps <- individual.conditional.probability(ptheta,dx[i,],probs.array,combinations,thetas.counts,CPTs, ptop)
    #ps["probs"] <- normalize.vector(ps["probs"])
    if(simple.vals == 0){
      for(j in 1:nrow(ps)){
        d <- rbind(d,setNames(c(dx[i,],ps[j,2:ncol(ps)]),names(d)))
      }
    }else {
      th <- c()
      ps["probs"] <- normalize.vector(ps["probs"])

      if(simple.vals == 1){
              for(j in 1:(ncol(ps)-2)){
                th <- c(th, sum(ps[,ncol(ps)]*combinations[,j+1]))
              }
        d <- rbind(d,setNames(c(dx[i,],th,weight = 1),names(d)))
      }
      if(simple.vals == 2){
        th <- ps[which.max(ps[,ncol(ps)]),2:(ncol(ps)-1)]
        #th <- combinations[which.max(ps[,ncol(ps)]),]
        if(which.max(ps[,ncol(ps)]) < nrow(combinations)){
          a1 <- 0
          a2 <- nrow(combinations)
        } else {
          a1 <- nrow(combinations)
          a2 <- 0
        }

        #tprobs <- c(ps[which.max(ps[,ncol(ps)])-a1,"probs"],ps[which.max(ps[,ncol(ps)])+a2,"probs"])
        #tprobs <- normalize.vector(tprobs)
        #th <- cbind(th, weight = 1, tprobs[1], tprobs[2])
        th <- cbind(th, weight = 1)
        d <- rbind(d,setNames(c(dx[i,],th),names(d)))

      }


    }
  }
  return(d)
}

normalize.vector <- function(x){
  return(x/sum(x))
}


#"./data/data_TF_noev_281_unobs/set"
run.bayes.net <- function(datafolder, fold, adj.matrix, states, top.parents = 0, cycles = 10, simple.vals = 2, max.iter = 50){
  data <- read.table(paste0(datafolder,"set",fold,"_learn.dat"), header = TRUE, sep = ",")
  vals <- as.list(data)
  res <- list()
  M <- list()
  for(i in 1:cycles){
    res[[i]] <- run.estimation(vals, adj.matrix, states, max.iter = max.iter, simple.vals = 2, top.parents = top.parents)
    res[[i]]$CPTs <- get.table.probs(res[[i]]$coefs, states)
  }

  return(res)
}

run.estimation <- function(vals, adj.matrix, states = 3, max.iter = 60,simple.vals = 2, tolerance = 1e-3, top.parents = 0){
  children <- length(vals)
  thetas <- ncol(adj.matrix)

  const <- rnorm(children,0,0.5)
  coefs <- adj.matrix
  coefs[coefs == 1] <- runif(sum(coefs),0.5,1.5)
  coefs <- cbind(const,coefs)

  old.coefs <- coefs
  old.coefs <- old.coefs * 0
  old.ll <- 0

  CPTs = NULL
  ptop = rep(1,thetas)
  if(top.parents > 0){
    CPTs <- list()
    topstates <- 2
    for(i in 1:thetas){
      CPTs[[i]] <- matrix(c(0.8,0.5,0.2,0.2,0.5,0.8),ncol=topstates)
    }
    ptop <- c(0.5,0.5)
  }

  ptheta <- matrix(rep(1/states,states*thetas), nrow = thetas)
  i <- 0

  vals <- data.frame(vals)
  while(abs(sum(old.coefs - coefs)) > tolerance && (i < max.iter)){
    i <- i+1
    cat("Step ",i,"\n")

    new.priors <- all.conditional.probs(coefs,ptheta,vals,simple.vals, apply(adj.matrix,2,sum), CPTs, ptop, top.parents)

    #if(sum(is.nan(new.priors[,"theta1"])) != 0) browser()
    if(simple.vals == 0){
      for(th in 1:thetas){
        the <- paste0("theta",th)
        # ptheta[th,1] <- sum((new.priors[,the] == -1) * new.priors[,"weight"])
        # ptheta[th,2] <- sum((new.priors[,the] == 0)  * new.priors[,"weight"])
        # ptheta[th,3] <- sum((new.priors[,the] == 1)  * new.priors[,"weight"])
        for(state in 1:states){
          ptheta[th,state] <- sum((new.priors[,the] == (state -ceiling(states/2))) * new.priors[,"weight"])
        }
        ptheta[th,] <- normalize.vector(ptheta[th,])
      }
    } else {

      for(th in 1:thetas){
        the <- paste0("theta",th)
        for(state in 1:states){
          ptheta[th,state] <- sum(new.priors[,the] == (state -ceiling(states/2)))
        }
        #ptheta[th,1] <- sum(mapply(max,0,-new.priors[,the]))
        #ptheta[th,2] <- sum(mapply(max,0,1 - abs(new.priors[,the])))
        #ptheta[th,3] <- sum(mapply(max,0,new.priors[,the]))
        ptheta[th,] <- normalize.vector(ptheta[th,])
      }
    }

    the <- c("theta1")
    for(th in 2:thetas){
      the <- c(the,paste0("theta",th))
    }

    if(top.parents > 0){
      data <- new.priors[,the]+floor(states/2)+1
      CPTs <- m.simpe.bayes(data, new.priors[,"top1"])
      #ptop <- c(sum(new.priors[,"probs1"])/nrow(new.priors),sum(new.priors[,"probs2"])/nrow(new.priors))
      #ptop <- normalize.vector(ptop)
      #ptop <- c(length(which(new.priors[,"top1"] == 1))/nrow(new.priors),length(which(new.priors[,"top1"] == 2))/nrow(new.priors))
      #print(ptop)
    #ptheta <- ptheta * 0 +1/3
    }

    res <- get.new.coefs(new.priors, adj.matrix)

    old.coefs <- coefs
    coefs <- res[[1]]
    ll <- llikelihood(coefs, vals, ptheta)

    #cat("\n")
    #print(ptheta)

    print(sum(ll))
    print(sum(old.ll) - sum(ll))

    old.ll <- ll
  }
  return(list(coefs = coefs, new.priors = new.priors, vals = vals, max.reached = i==max.iter, log.lik = sum(ll), ptheta = ptheta, top.CPTs = CPTs, top.pt = ptop))
}

e.simple.BN <- function(data, cpts, priors, topstates){
  states <- c()
  for(j in 1:length(data[[1]])){
    pstates <- priors
    for(i in 1:length(data)){
      pstates <- pstates * cpts[[i]][data[[i]][j] + 1,]
    }
    pstates <- normalize.vector(pstates)
    #pstates <- (which.max(pstates)-1)
    states <- c(states,pstates)
  }
  return(matrix(states,nrow = topstates))
}

m.simpe.bayes.2 <- function(data, states, old.cpts){
  #browser()
  topstates <- 2
  sstates <- 3
  cpts <- list()
  for(d in 1:length(data)){ #for all lower level variables
    cpt <- matrix(rep(0,topstates*sstates),ncol=topstates)
    for(i in 1:topstates){ #over states of top variable
      #ids <- which(states == (i-1))

      for(j in 1:sstates){ # for all its states
        cpt[j,i] <- sum((states[i,]*old.cpts[[d]][j,i])[data[[d]] == (j-1)]) / sum(states[i,]) #[data[[d]] == (j-1)]
      }
      cpt[,i] <- normalize.vector(cpt[,i])
    }
    #cpts[[d]] <- (old.cpts[[d]] + cpt) /2
    cpts[[d]] <- cpt
  }
  return(cpts)
}

m.simpe.bayes.3 <- function(data, states, old.cpts){
  #browser()
  topstates <- 2
  sstates <- 3
  cpts <- list()
  for(d in 1:length(data)){ #for all lower level variables
    cpt <- matrix(rep(0,topstates*sstates),ncol=topstates)
    for(i in 1:topstates){ #over states of top variable
      sums <- c()
      for(j in 1:sstates){ # for all its states
        ids <- which(data[[d]] == (j-1))
#         pp <- c()
#         for(idd in ids){
#           pp <- c(pp, old.cpts[[3-i]][data[[3-i]][idd]+1,i])
#         }
        sums <- c(sums, sum(states[i,ids]))
      }
      for(j in 1:sstates){ # for all its states
        cpt[j,i] <- sums[j]/(sum(sums))
      }
    }

    #cpts[[d]] <- (old.cpts[[d]] + cpt) /2
    cpts[[d]] <- cpt
  }
  return(cpts)
}

m.simpe.bayes <- function(data, states, old.cpts){

  topstates <- 2
  sstates <- 3
  cpts <- list()
  for(d in 1:length(data)){ #for all lower level variables
    cpt <- matrix(rep(0,topstates*sstates),ncol=topstates)
    for(i in 1:topstates){ #over states of top variable
      ids <- which(states == (i))
      for(j in 1:sstates){ # for all its states
        cpt[j,i] <- length(which(data[[d]][ids] == (j))) / length(ids)
      }
    }
    cpt[cpt == 0] <- 0.0001
    #cpts[[d]] <- (old.cpts[[d]] + cpt) /2
    cpts[[d]] <- cpt
  }
  return(cpts)
}
simple.em <- function(data, max.iter = 1000, tolerance = 1e-3, cycles = 10 ){
  topstates <- 2
  sstates <- 3
  thetas <- 7
  cpts <- list()
  res <- list()
  for(cycle in 1:cycles){
    for(i in 1:thetas){
      if(cycle == 1){
        cpts[[i]] <- matrix(c(0.8,0.5,0.2,0.2,0.5,0.8),ncol=topstates)
      } else {
        cpts[[i]] <- matrix(runif(topstates*sstates),ncol=topstates)
      }
    }
    log.liks <- c()
    priors <- rep(1/topstates,topstates)
    i <- 1
    while(i < max.iter){
      if(length(log.liks) > 2){
        if(abs(log.liks[length(log.liks)]-log.liks[length(log.liks)-1]) < tolerance){
          break
        }
      }
      states <- e.simple.BN(data,cpts,priors,topstates)
      cpts <- m.simpe.bayes.3(data,states,cpts)
      pp <- sum(states[1,]) / length(states[1,])
      priors <- c(pp,1-pp)
      log.lik <- simple.em.log.lik(data,states,cpts)
      #print(priors)
      #print(cpts)
      #print(log.lik)
      log.liks <- c(log.liks, log.lik)
      i <- i +1
    }
    res[[cycle]] <- list(CPTs = cpts,priors = priors,log.lik = log.lik)
  }
  return(res)
}

simple.em.log.lik <- function(data, states, cpts){
  lik <- c();
  for(d in 1:length(data[[1]])){ #for all observations
    single.probability <- 1
    for(i in 1:length(cpts)){ #for all variables
      single.probability <- single.probability*
        sum(cpts[[i]][(data[[i]][d] + 1),]*states[,d])
    }
    lik <- c(lik,single.probability)
  }
  return(sum(log(lik)))
}
