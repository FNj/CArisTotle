library(stringr)
#source("./packageSource/classes_real.R")
#source("./packageSource/parser_classes.R")

#' Function to create a new empty \code{\link{NodeList-class}}.
#' @export
NodeList <- function(){
  new("NodeList",number.of.nodes = 0,
      nodes.names = c(),
      nodes = list())
}

# function for adding structural elements (lists,vectors) to a list
add.to.list=function(lst,el){
  unlist(list(lst,list(el)),recursive=FALSE)
}

#  Loading .net network into R S4 object.
#  @param data.source input .net file
#  @return Loaded network
load.network <- function(data.source, is.file = TRUE){
  if(is.file){
    data.source = readLines(data.source)
  }
  nodes <- get.all.nodes(data.source)
  #adj.table <- create.adjactency.table(node.names(nodes))
  adj.table <- create.adjactency.table(c(1:nodes@number.of.nodes))
  res <- process.all.potentials(data.source, adj.table, nodes)
  res$nodes <- nodes
  return(res) #adj.matrix, potentials, nodes
}

# create an empty named conditional table
create.adjactency.table <- function(node.names){
  d <- length(node.names)
  dnames <- list(node.names,node.names)
  A <- matrix(0,d,d,dimnames=dnames)
  return(A)
}

# parse all potentials
process.all.potentials <- function(data, adj.matrix, nodes){
  potentials.starts <- get.texts.of.type("potential ", data)
  potentials <- list()
  for(start in potentials.starts){
    pot <- data[start:length(data)]
    res <- process.potential(pot,adj.matrix,nodes)
    potentials <- add.to.list(potentials,res$a)
    adj.matrix <- res$adj.matrix
  }
  return(list(adj.matrix=adj.matrix,potentials=potentials))
}

# parse single potential
process.potential <- function(potential.text, adj.matrix, nodes){
  potential.text <- trim.end(potential.text)
  affected.nodes <- get.item("potential",potential.text)

  if(length(affected.nodes) > 1){
    #remove separator
    affected.nodes <- affected.nodes[-2]
    for(i in 2:length(affected.nodes)){
      #adj.matrix[affected.nodes[1],affected.nodes[i]] <- 1
      #adj.matrix[affected.nodes[i],affected.nodes[1]] <- 1
      adj.matrix[node.index(nodes,affected.nodes[i])
                 ,node.index(nodes,affected.nodes[1])] <- 1
    }
  }
  a.nodes <- nodes[affected.nodes]

  a <- process.cond.table(get.potential.table.text(potential.text),a.nodes)
  pot <- list(a=a, i=nodes.indexes(nodes,affected.nodes))
  pot <- reorder.potential(pot)
  return(list(a=pot,adj.matrix=adj.matrix))
}

# reorder potential to incresing in terms of node numbers
reorder.potential <- function(potential){
  i <- order(potential$i)
  a <- aperm(potential$a,i)
  return(list(a=a,i=potential$i[i]))
}

# parse the text of one conditional table from the text file
get.potential.table.text <- function(text){
  #find the start and the end of table
  s <- grep("data",text)[1]
  e <- grep(";",text)[1]

  #cut it off
  text <- text[s:e]
  return(text)
}

# parse the conditional table
process.cond.table <- function(t, nodes){
  #browser()
  #get brackets
  pattern <- "\\([[:alnum:][:space:]\\.\\-]+\\)"
  t <- str_extract_all(t,pattern)
  t <-  paste(t, collapse = ' ')

  pattern <- "[[:digit:]E\\.\\-]+"
  t <- str_extract_all(t,pattern)
  t <- as.numeric(t[[1]])

  #t <-str_replace_all(t,"\\(|\\)","")
  #pattern <- "[[:digit:]\\.]+"
  #t <- str_extract_all(t,pattern)[[1]]

  d <- node.states(nodes)
  if(prod(d) == length(t)-1){
    t <- t[2:length(t)]
  }

  #order the array for loading
  if(length(d) > 1){
    d<- d[c(1,length(d):2)]
  }

  #load values
  a <- array(0,dim=d)
  a[] <- t

  #reorder the array after loading
  if(length(d) > 1){
    a <- aperm(a,c(1,length(d):2))
    d<- d[c(1,length(d):2)]
  }
  return(a)
}

# returns all occurences of type in data
get.texts.of.type <- function(type, data){
  node_starts <- grep(type,data)
  return(node_starts)
}

# parse all nodes
get.all.nodes <- function(node.text){
  l <- NodeList()
  nodes.starts <- get.texts.of.type("node ", node.text)
  for(i in 1:length(nodes.starts)){
    node <- process.node(node.text[nodes.starts[i]:length(node.text)])
    l <- add(l,node)
  }
  return(l)
}

# parse one individual node
process.node <- function(node.text){
  node.text <- trim.end(node.text)
  node.name <- get.item("node",node.text)
  states.names <- get.item("states",node.text)
  number.of.states <- length(states.names)
  subtype <- get.item("subtype",node.text)

  node <- new("Node",name=node.name,states.names=states.names
              ,number.of.states=number.of.states)
  return(node)
}

# trims the end of object in text file (ending with {)
trim.end <- function(node.text){
  return(node.text[1:grep("}",node.text)[1]])
}

# parse text of the specific item in the text file
get.item <- function(item_name, text){
  #browser()
  #get the rest without the keyword
  t <- str_match(text[grep(item_name,text)],paste(item_name,"(.+)"))[2]

  #if the item is in brackets
  if(grepl("\\(",t) == TRUE){
    #if the item is not in "
    if(grepl("\"",t) == FALSE){
      t <- substr(t,(regexpr("\\(",t)[1]+1),(regexpr("\\)",t)[1]-1))
      t <- str_split(str_replace_all(t,"\"","")," ")
      t <- unlist(t)
    } else {
      c <- c()
      pos <- gregexpr("\"",t[1])
      pos <- pos[[1]]
      for(i in 1:(length(pos)/2)){
        c <- c(c, substr(t,pos[(2*i-1)]+1,pos[2*i]-1))
      }
      t <- c
    }
  } else {
    #if the item is after =
    if(grepl("=",t) == TRUE){
      t <- substr(t,(regexpr("=",t)[1]+2),(regexpr(";",t)[1]-1))
    }
  }
  return(t)
}
