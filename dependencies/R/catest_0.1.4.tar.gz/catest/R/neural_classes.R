#library(neuralnet)
#' Class representing an instance of a neural network.
#' @aliases NeuralNetwork
setClass("NeuralNetwork", representation(nn1 = "list", nn2 = "list", currentState = "vector", #vars = "numericORcharacter",
                                          nodes = "NodeList", questionChances = "numeric", minus = "logical",
                                         skill.vars = "character", skill.indexes = "numeric", version="character"))

#' Function to create a new instance of a NeuralNetwork
#' @param learn.file file contatining learn data
#' @param version version of the neural network
#' #' \enumerate{
#' \item mlp
#' \item rbf
#' }
#' @param net.nodes NodeList class object containing nodes of the network as instances of the class Node
#' @param hidden vector specifing the structure of hidden layers (each number is the number of nodes in a layer, number of values sets the number of layers)
#' @param hidden.back vector specifing the structure of backwards hidden layers (each number is the number of nodes in a layer, number of values sets the number of layers)
#' @param minus selectes whether -1 should be used to encode false answers (otherwise 0)
#' @export
create.net <- function(learn.file, version,  net.nodes, hidden = c(5), hidden.back = c(5), minus = F){
  #if(type == "neuralnet"){
  # data <- create.net.neural(learn.file, version = version)

  #}
  #if(type == "RSNNS"){
  data <- create.net.RSNNS(learn.file, version = version,  hidden = hidden, hidden.back = hidden.back, minus)

  #}

  net <- new("NeuralNetwork", nn1 = data$net1, nn2 = data$net2,
                       currentState = data$current.state, nodes = net.nodes,
                       questionChances = data$freq, version = version, minus = minus)
  return(net)
}

#net.n - network nodes
neural.testing <- function(input.folder, out.folder, net.n,
                           folds = 1:10, t.start = 1, t.end = -1,
                           hidden = c(5), hidden.back=c(5), sink = TRUE, minus = FALSE, freq=TRUE){
  create.dirs(out.folder)
  if(sink){
    file.name <- paste(out.folder,"out.txt",sep="")
    file.name2 <- paste(out.folder,"log.txt",sep="")
    of <- file(file.name2, "w")
    sink(file.name,append=FALSE,type = "output")
    sink(of,append=FALSE,type = "message")

    a <- system("svn info", intern = TRUE)
    print(a)
    print(as.list(match.call()))
    print(input.folder)
    print(version)
    print(folds)
    print(hidden)
    print(hidden.back)

  }
  for(fold in folds){
    cat("\n------------------------\n")
    cat(c("\nRUNNING FOLD ",fold))
    cat("\n------------------------\n")
    input.file <- paste0(input.folder,"set",fold,"_test.dat")
    learn.file <- paste0(input.folder,"set",fold,"_learn.dat")
    points.file <- paste0(input.folder,"huginMaxPoints.dat")
    data <- create.net(learn.file, version = version, hidden = hidden, hidden.back = hidden.back, minus)

#loading net nodes - fix THIS
    load("./data/network.nodes.Rdata")
    if(!freq){
      data$freq <- rep(0,length(data$freq))
      names(data$freq) <- names(data$current.state)
    }
    neural.test <- new("NeuralNetwork", nn1 = data$net1, nn2 = data$net2,
                                          #currentState = (data$freq - 0.5)*2, nodes = net.n,
                                          currentState = data$current.state, nodes = net.n,
                                          questionChances = data$freq, minus = minus)

    save(neural.test, file = paste0(out.folder,"fold",fold,"/nnnet.Rdata"))
    test.collection <- load.simulation.data(input.file, NULL)

    testing.simulation(neural.test, test.collection, selection.criterion=1,
                output.path = paste0(out.folder,"fold",fold), start=1, end=-1)
  }
}

create.dirs <- function(out.folder){
  dir.create(out.folder)
  for(i in 1:10) dir.create(paste0(out.folder,"fold",i))
}

read.train.data <- function(input.file, minus = FALSE){
  train.data <- read.table(input.file,header = TRUE, sep = ",")
  #train.data <- train.data[,12:length(names(train.data))]
  names <- paste(names(train.data[1:length(names(train.data))-1]),collapse = "+")

  train.data['S1'] <- apply(train.data[,1:(ncol(train.data) - 1)],1,sum)

  if(minus){
    train.data[train.data == 0] <- -1
    train.data['S1'][train.data['S1'] == -1] <- 0
  }

  rel.freq <- colSums(train.data)/nrow(train.data)

  if(names(rel.freq)[length(rel.freq)] == "S1"){
    rel.freq <- rel.freq[1:(length(rel.freq)-1)]

  }
  current.state <- train.data[1,1:(length(rel.freq))]
  current.state[1:(length(rel.freq))] <- rel.freq

  #train.data[train.data == 0] <- -1
  #train.data['S2'] <- 0
  #train.data['S3'] <- 0
  #train.data[which(train.data[,'S1'] == 2),'S2'] <- 1
  #train.data[which(train.data[,'S1'] == 3),'S3'] <- 1
  #train.data[which(train.data[,'S1'] == 2),'S1'] <- 0
  #train.data[which(train.data[,'S1'] == 3),'S1'] <- 0


  return(list(data = train.data, names = names, freq = rel.freq, cs = current.state))
}

enlarge.learning.set <- function(td, tard){
  rowlength <- length(td[1,])
  rows <- nrow(td)
  repetition <- 30
  tres <- 0.6
  new.td <- td
  new.tard <- tard
  for(i in 1:nrow(td)){
    for(j in 1:repetition){
      rand <- runif(rowlength)
      new.td[rows + ((i-1)*repetition+j),] <- td[i,]
      new.td[rows + ((i-1)*repetition+j),rand < tres] <- 0
      new.tard[rows + ((i-1)*repetition+j),] <- tard[i,]
    }
  }
  return(list(td = new.td, tard = new.tard))
}


create.net.RSNNS <- function(input.file, version = 'rbf', hidden = c(5), hidden.back = c(5), minus = FALSE){
  stopifnot(version %in% c('rbf','mlp'))
  input <- read.train.data(input.file, minus)

  td <- input$data[,1:(length(input$data[1,])-1)]
  tard <- input$data[,(length(input$data[1,])):(length(input$data[1,]))]
  #en <- enlarge.learning.set(td, tard)
  if(version == 'mlp'){
    net <- mlp(td, tard, size = hidden)
    net.back <- mlp(tard, td, size = hidden.back)
    net <- list(net)
    net2 <- list(net.back)
  }

  if(version == 'rbf'){
    r <- 1000
    while(r > 150 || r < 0){
      net <- rbf(td, tard, size = hidden)
      r <- predict(net,rep(1,53))
    }

    a <- rep(-5,53)
    while((sum(a < -2) + sum(a > 3)) > 5){
      net.back <- rbf(tard, td, size = hidden.back)
      a <- predict(net.back, 0)
    }
    net <- list(net)
    net2 <- list(net.back)
  }

  return(list(net1 = net,net2 = net2, freq = input$freq, current.state = input$cs))
}


# create.net.neural <- function(input.file, version = 1){
#   input <- read.train.data(input.file)
#
#   if(version == 1){
#     net <- neuralnet(paste0("S1+S2+S3","~",input$names), input$data)
#     net.back <- neuralnet(paste0(input$names,"~","S1+S2+S3"), input$data)
#     net <- list(net)
#     net2 <- list(net.back)
#   }
#   if(version == 2){
#     net <- neuralnet(paste0("S1+S2+S3","~",input$names), input$data, hidden = 10)
#     net.back <- neuralnet(paste0(input$names,"~","S1+S2+S3"), input$data, hidden = 10)
#     net <- list(net)
#     net2 <- list(net.back)
#   }
#   if(version == 3){
#     net <- neuralnet(paste0("S1+S2+S3","~",input$names), input$data)
#     net.back <- neuralnet(paste0(input$names,"~","S1+S2+S3"), input$data, hidden = 10)
#     net <- list(net)
#     net2 <- list(net.back)
#   }
#   if(version == 4){
#     net <- neuralnet(paste0("S1+S2+S3","~",input$names), input$data, hidden = 10)
#     net.back <- neuralnet(paste0(input$names,"~","S1+S2+S3"), input$data)
#     net <- list(net)
#     net2 <- list(net.back)
#   }
#
#   return(list(net1 = net,net2 = net2, freq = input$freq, current.state = input$cs))
# }
