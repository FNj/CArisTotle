library(gRbase)
#library(rcdd)
#source("./packageSource/class_functions_real.R")
#source("./parser_classes")

setMethod("show", "BayesianNetwork",
          function(object){
            cat("Bayesian network model:\n")
            arr <- matrix(c(length(object@vars),length(object@skill.vars),length(object@tables)),nrow = 1)
            colnames(arr) <- c("Number of vars", "Number of skill vars", "Number of CPTs")
            print(arr)
            cat("\n")
            cat("Question vars\n")
            print(object@nodes@nodes.names[!(object@nodes@nodes.names %in% object@skill.vars)])
            cat("\n")
            cat("\n")
            cat("Skill vars\n")
            print(object@skill.vars)

            cat("\n")
          }
)

#' Function to retrieve question nodes from the network
#' @param net the net object
#' @exportMethod get.questions
setGeneric("get.questions", function(net) standardGeneric("get.questions"))
setMethod("get.questions", signature(net="BayesianNetwork"),function(net){
  return(net@nodes@nodes.names[!(net@nodes@nodes.names %in% net@skill.vars)])
  }
)

#' Function to retrieve skill nodes from the network
#' @param net the net object
#' @exportMethod get.skills
setGeneric("get.skills", function(net) standardGeneric("get.skills"))
setMethod("get.skills", signature(net="BayesianNetwork"),function(net){
  return(net@skill.vars)
}
)

setGeneric("table.array", function(e1) standardGeneric("table.array"))
#setMethod("table.array", "RationalConditionalTable",function(e1){if(is.character(e1@a)){return(q2d(e1@a))}else{return(e1@a)}})
setMethod("table.array", "RealConditionalTable",function(e1){return(e1@a)})

#' Compares two conditional tables.
#' @param e1 the first table
#' @param e2 the second table
setMethod("==", "ConditionalTable",
          function(e1,e2){
            if(length(dim(e1@a))!=length(dim(e2@a))) return(FALSE)
            if(!all(dim(e1@a) == dim(e2@a))) return(FALSE)
            if(all(e1@a==e2@a)) return(TRUE)
            return(FALSE)
          }
)

# setMethod("==", "BiConditionalTable",
#           function(e1,e2){
#             if((e1@real == e2@real) && (e1@rational == e2@rational)) return(TRUE)
#             return(FALSE)
#           }
# )

setMethod("show", "ConditionalTable",
          function(object){
            cat("PROBABILITY:\n")
            print(table.array(object))
            cat("\nVARS:\n")
            print(object@i)
            cat("\n")
          }
)

# setMethod("show", "BiConditionalTable",
#   function(object){
#     cat("REAL TABLE\n")
#     print(object@real)
#     cat("RATIONAL TABLE\n")
#     print(object@rational)
#     cat("TABLES DIFFERENCE\n")
#     print(q2d(qmq(object@real@a,object@rational@a)))
#   }
# )

# setMethod("show", "Operation",
#            function(object){
#              print.history(object)
#    }
# )

setGeneric("table.dim", function(e1) standardGeneric("table.dim"))
setMethod("table.dim", signature(e1="ConditionalTable"),
          function(e1) {
            return(dim(e1@a))
          }
)
# setMethod("table.dim", signature(e1="BiConditionalTable"),
#           function(e1) {
#             return(dim(e1@real@a))
#           }
# )



# setMethod("*", signature(e1="BiConditionalTable", e2="BiConditionalTable"),
#           function(e1, e2) {
#             real<-e1@real*e2@real
#             rat<-e1@rational*e2@rational
#             #operation <- add.to.history(op="*",tab1=e1,tab2=e2)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
# setMethod("*", signature(e1="RationalConditionalTable", e2="RationalConditionalTable"),
#           function(e1, e2) {
#             i<-combine.indexes(e1@i,e2@i)
#             return(new("RationalConditionalTable",a=qxq(e1@a,e2@a),i=i))
#           }
# )

#'  to multiply two conditional tables.
#' @param e1 first conditional table
#' @param e2 second conditional table
#'
setMethod("*", signature(e1="RealConditionalTable", e2="RealConditionalTable"),
          function(e1, e2) {
            i<-combine.indexes(e1@i,e2@i)
            return(new("RealConditionalTable",a=e1@a*e2@a,i=i))
          }
)
# setMethod("/", signature(e1="BiConditionalTable", e2="BiConditionalTable"),
#           function(e1, e2) {
#             real<-e1@real/e2@real
#             rat<-e1@rational/e2@rational
#             #operation <- add.to.history(op="/",tab1=e1,tab2=e2)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
# setMethod("/", signature(e1="RationalConditionalTable", e2="RationalConditionalTable"),
#           function(e1, e2) {
#             i<-combine.indexes(e1@i,e2@i)
#             return(new("RationalConditionalTable",a=qdq(e1@a,e2@a),i=i))
#           }
# )

#' Method to divide two conditional tables.
#' @param e1 first conditional table
#' @param e2 second conditional table
setMethod("/", signature(e1="RealConditionalTable", e2="RealConditionalTable"),
          function(e1, e2) {
            i<-combine.indexes(e1@i,e2@i)
            return(new("RealConditionalTable",a=e1@a/e2@a,i=i))
          }
)

# #' Method to create outer product of two conditional tables.
# #' @param e1 the first conditional table
# #' @param e2 the second conditional table
# #' @param op multiplication or division operation
setGeneric("table.outer", function(e1,e2,op) standardGeneric("table.outer"))
# setMethod("table.outer", signature(e1="BiConditionalTable", e2="BiConditionalTable"),
#           function(e1, e2, op="*") {
#             real<-table.outer(e1@real,e2@real)
#             rat<-table.outer(e1@rational,e2@rational)
#             #operation <- add.to.history(op="outer",tab1=e1,tab2=e2)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
# setMethod("table.outer", signature(e1="RationalConditionalTable", e2="RationalConditionalTable"),
#           function(e1, e2, op="*") {
#             a1 <- e1@a
#             a2 <- e2@a
#             if (length(e1@i)==1) a1 <- as.vector(a1)
#             if (length(e2@i)==1) a2 <- as.vector(a2)
#             return(new("RationalConditionalTable",a=q.outer(a1,a2,op)))
#           }
# )
setMethod("table.outer", signature(e1="RealConditionalTable", e2="RealConditionalTable"),
          function(e1, e2, op="*") {
            a1 <- e1@a
            a2 <- e2@a
            if (length(e1@i)==1) a1 <- as.vector(a1)
            if (length(e2@i)==1) a2 <- as.vector(a2)
            return(new("RealConditionalTable",a=outer(a1,a2,op)))
          }
)

# #' Method to create a permutation of a conditional table.
# #' @param e1 conditional table
setGeneric("table.aperm", function(e1) standardGeneric("table.aperm"))
# setMethod("table.aperm", signature(e1="BiConditionalTable"),
#           function(e1) {
#             real<-table.aperm(e1@real)
#             rat<-table.aperm(e1@rational)
#             #operation <- add.to.history(op="aperm",tab1=e1)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
setMethod("table.aperm", signature(e1="ConditionalTable"),
          function(e1) {
            return(new(class(e1),a=aperm(e1@a),i=e1@i))
          }
)

# #' Method to marginalize a table down to one variable.
# #' @param e1 the conditional table
# #' @param i the node name
setGeneric("table.from.table.sum", function(e1,i) standardGeneric("table.from.table.sum"))
# setMethod("table.from.table.sum", signature(e1="BiConditionalTable"),
#           function(e1) {
#             real<-table.aperm(e1@real)
#             rat<-table.aperm(e1@rational)
#             #operation <- add.to.history(op="Table_from_table_sum",tab1=e1)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
setMethod("table.from.table.sum", signature(e1="ConditionalTable"),
          function(e1,i) {
            table<-new(class(e1),a=array(table.sum(e1),dim=c(1)),i=i)
            return(table)
          }
)

# Normalize to [0,1] interval, take only real part of complex numbers.
# If the sum of all values is negative return uniform distribution
setGeneric("normalize", function(e1) standardGeneric("normalize"))
# setMethod("normalize", signature(e1="BiConditionalTable"),
#           function(e1) {
#             #if (table.sum(e1@real) <= 0) browser()
#             real<-normalize(e1@real)
#             rat<-normalize(e1@rational)
#             #operation <- add.to.history(op="normalize",tab1=e1)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
setMethod("normalize", signature(e1="ConditionalTable"),
          function(e1) {
            #DOES NOT SUPPORT COMPLEX*******************
            e1@a <- as.array(pmax(0,e1@a))

            #if (sum(Re(tab$a)) <= 0){ # set all values to one
            if (table.sum(e1) <= 0){ # set all values to one
              stop(paste("The inference algorithm encountered a problem. Most likely an impossible evidence was propagated.","\n"))
              print(e1@a)
              if (length(dim(table.dim(e1))) <= 1){
                e1@a <- array(1, dim=c(length(e1@a)))
              }else{
                e1@a <- array(1, dim=dim(table.dim(e1)))
              }
            }
            #return(list(a=Re(tab$a)/Re(sum(tab$a)),i=tab$i))
            #return(new(class(e1),a=table.norm.divide(e1),i=e1@i))
            e1@a <- table.norm.divide(e1)
            return(e1)
          }
)
setGeneric("table.sum", function(e1) standardGeneric("table.sum"))
# setMethod("table.sum", signature(e1="RationalConditionalTable"),
#           function(e1) {
#             return(qsum(e1@a))
#           }
# )
setMethod("table.sum", signature(e1="RealConditionalTable"),
          function(e1) {
            return(sum(Re(e1@a)))
          }
)

setGeneric("table.apply.sum", function(e1,d,i,dim) standardGeneric("table.apply.sum"))
# setMethod("table.apply.sum", signature(e1="BiConditionalTable"),
#           function(e1,d,i,dim) {
#             real<-table.apply.sum(e1@real,d,i,dim)
#             rat<-table.apply.sum(e1@rational,d,i,dim)
#             #operation <- add.to.history(op="apply_sum",tab1=e1)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
# setMethod("table.apply.sum", signature(e1="RationalConditionalTable"),
#           function(e1,d,i,dim) {
#             a<-apply(e1@a,d,qsum)
#             if (length(i) == 1) a <- array(a,dim=c(dim))
#             table <- new("RationalConditionalTable",a=a,i=i)
#             return(table)
#           }
# )
setMethod("table.apply.sum", signature(e1="RealConditionalTable"),
          function(e1,d,i,dim) {
            a<-apply(e1@a,d,sum)
            if (length(i) == 1) a <- array(a,dim=c(dim))
            table <- new("RealConditionalTable",a=a,i=i)
            return(table)
          }
)

setGeneric("table.arep", function(e1,i.new,d) standardGeneric("table.arep"))
# setMethod("table.arep", signature(e1="BiConditionalTable"),
#           function(e1,i.new,d) {
#             real<-table.arep(e1@real,i.new,d)
#             rat<-table.arep(e1@rational,i.new,d)
#             #operation <- add.to.history(op="arep",tab1=e1)
#             #bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i,history=operation)
#             bt<-new("BiConditionalTable",real=real,rational=rat,i=real@i)
#             if(compare.arrays.relative(bt)) browser()
#             return(bt)
#           }
# )
setMethod("table.arep", signature(e1="ConditionalTable"),
          function(e1,i.new,d) {

            e1@a <- arep(e1@a, i.new, d)
            return(e1)
          }
)

setGeneric("table.norm.divide", function(e1) standardGeneric("table.norm.divide"))
# setMethod("table.norm.divide", signature(e1="RationalConditionalTable"),
#           function(e1) {
#             return(divideQ(e1@a,qsum(e1@a)))
#           }
# )
setMethod("table.norm.divide", signature(e1="RealConditionalTable"),
          function(e1) {
            return(e1@a/sum(e1@a))
          }
)


#' The constructor for the junction tree S4 object
#' @param adj.matrix adjectancy matrix of a moral graph
#' @param tables list of CPTs
#' @export
JunctionTree <- function(adj.matrix,tables){
  tree<-jTree(as(adj.matrix,"graphNEL"))
  clq.tables <- tables.for.cliques(tree,tables)
  new("JunctionTree",cliques=tree$cliques,separators=tree$separators,parents=tree$parents,nr.cliques=length(tree$cliques),
      adjacent=adjacent.cliques(tree), clique.tables=clq.tables)
}


empty.conditional.table <- function(){
  return(new("ConditionalTable",a=array(c(0)),i=0))
}

#' Function to create an instance of \code{\link{BayesianNetwork-class}}
#' @param adj.matrix adjactency matrix of the network structure.
#' @param tables \code{\link{ConditionalTable}s} list containing CPTs of the network.
#' @param skill.vars names of variables which make skill nodes in the network.
#' @param nodes an instance of \code{\link{NodeList-class}} containing all nodes in the network.
#' @param biconditional.tables this parameter is not currently used, outdated, was used for rational conditional tables
#' @examples
#' # Constructing the network with three variables skill S1, and questions X1, X2
#' #adjactency matrix
#' adj.matrix <- matrix(c(0,1,1,0,0,0,0,0,0),nrow = 3)
#'
#' #conditional probabilities tables as list - will be converted to CPT internally
#' tables <- list()
#' a <-  array(c(0.8,0.3,0.2,0.7),dim = c(2,2))
#' tables[[1]] <- list(a=a,i = c(1,2))
#' a <-  array(c(0.15,0.75,0.85,0.25),dim = c(2,2))
#' tables[[2]] <- list(a=a,i = c(1,3))
#' a <-  array(c(0.5,0.5))
#' tables[[3]] <- list(a=a,i = c(1))
#'
#' #skill vars names
#' #names of skill variables in the network
#' skill.vars <- c("S1")
#'
#' l <- NodeList()
#' node <- new("Node",name="S1",number.of.states=2)
#' l <- add(l,node)
#' node <- new("Node",name="X1",number.of.states=2)
#' l <- add(l,node)
#' node <- new("Node",name="X2",number.of.states=2)
#' l <- add(l,node)
#'
#' bn <- BayesianNetwork(adj.matrix,tables,skill.vars, l)
#' bn <- one.dimensional.marginals(bn, c(1,2,3))
#' bn@marginals
#'
#' @export
BayesianNetwork <- function(adj.matrix, tables, skill.vars, nodes, biconditional.tables=FALSE){
  om <- adj.matrix
  adj.matrix <- moralize(adj.matrix)
  adj.matrix <- triangulate(adj.matrix)
  tree<-JunctionTree(adj.matrix, tables)
  vars <- vars.lst(tables)
  stopifnot(length(nodes.indexes(nodes,skill.vars)) == length(skill.vars))
  bn <- new("BayesianNetwork", tables = tables, vars = vars,
      adj.matrix = adj.matrix,
      orig.adj.matrix = om,
      j.tree = tree,
      nodes = nodes,
      skill.vars=skill.vars,
      skill.indexes=nodes.indexes(nodes,skill.vars))
  if(biconditional.tables){
    bn <- set.tables.class(bn,bi=TRUE)
  } else {
    bn <- set.tables.class(bn,bi=FALSE)
  }
  return(bn)
}

conditional.table <- function(table){
  return(table@a)
}
table.vars <- function(table){
  if(is(table,"ConditionalTable")) return(table@i)
  else return(table$i)
}

set.tables.class <- function(network,rational=FALSE,bi=FALSE){
  for(i in 1:length(network@tables)){
    if(bi){
      #rat <- new("RationalConditionalTable",a=d2q(Re(network@tables[[i]]$a)),i=network@tables[[i]]$i)
      #real <- new("RealConditionalTable",a=Re(network@tables[[i]]$a),i=network@tables[[i]]$i)
      #history <- new("Operation",op="creation",tab1=empty.conditional.table())
      #network@tables[[i]] <- new("BiConditionalTable",rational=rat,real=real,history=history,i=network@tables[[i]]$i)
    } else {
      if(rational){
        #network@tables[[i]] <- new("RationalConditionalTable",a=d2q(network@tables[[i]]$a),i=network@tables[[i]]$i)
      } else {
        network@tables[[i]] <- new("RealConditionalTable",a=network@tables[[i]]$a,i=network@tables[[i]]$i,
                                   name=network@nodes@nodes.names[network@tables[[i]]$i])
        names(network@tables[[i]]@i) <-network@tables[[i]]@name
      }
    }
  }
  return(network)
}

setGeneric("find.singleton.tables", function(model) standardGeneric("find.singleton.tables"))
setMethod("find.singleton.tables", signature(model="BayesianNetwork"),
          function(model) {
            vars <- c()
            for(table in model@tables){
              if(length(table@i) == 1)
                vars <- c(vars, table@i)
            }
            return(vars)
          }
)
