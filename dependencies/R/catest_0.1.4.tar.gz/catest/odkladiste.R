



#' #NEURAL NETWORK CAT with generic model
#' #rbf network
#' version <- 'rbf'
#' #hidden layers sizes for forward network
#' hidden <- c(5)
#' #hidden layers sizes for backward network
#' hidden.back <- c(5)
#' #load NodeList of the neural network to be created
#' data("net.nodes")
#' #build the network
#' neural.net <- create.net(learn.filename, version = version, net.nodes = net.nodes, hidden = hidden, hidden.back = hidden.back, minus = FALSE)
#' #starting tests (in this case one test and selecting one question)
#' res <- testing.simulation(neural.net, tc, q, selection.criterion, stopping.criterion, start = start, end = end)
#'
#' #results are stored in a list where each simulated participant is in one item
#' #get the first (and only in this case) one
#' res <- res[[1]]
#'
#' #response pattern before any questions asked
#' get.response.pattern(res, 1)
#'
#' #selected question (field a holds information which state the answer was in)
#' get.evidence(res, 2)
#' #response pattern after one question asked
#' get.response.pattern(res, 2)


# Constructing the network with three variables skill S1, and questions X1, X2
#adjactency matrix
adj.matrix <- matrix(c(0,1,1,0,0,0,0,0,0),nrow = 3)

#conditional probabilities tables
tables <- list()
a <-  array(c(0.8,0.3,0.2,0.7),dim = c(2,2))
tables[[1]] <- new("RealConditionalTable",a=a,i = c(1,2))
a <-  array(c(0.15,0.75,0.85,0.25),dim = c(2,2))
tables[[2]] <- new("RealConditionalTable",a=a,i = c(1,3))
a <-  array(c(0.5,0.5))
tables[[3]] <- new("RealConditionalTable",a=a,i = c(1))

#skill vars names
#names of skill variables in the network
skill.vars <- c("S1")

l <- NodeList()
node <- new("Node",name="S1",number.of.states=2)
l <- add(l,node)
node <- new("Node",name="X1",number.of.states=2)
l <- add(l,node)
node <- new("Node",name="X2",number.of.states=2)
l <- add(l,node)

bn <- BayesianNetwork(adj.matrix,tables,skill.vars, l)
